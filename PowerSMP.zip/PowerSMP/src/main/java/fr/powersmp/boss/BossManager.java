package fr.powersmp.boss;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Boss configurables (section "bosses:" de config.yml), invoqués par un admin avec /powersmp boss spawn.
 * Tous les joueurs qui ont infligé assez de dégâts reçoivent le crédit (progression + butin).
 */
public final class BossManager {

    private final PowerSMP plugin;
    private final NamespacedKey bossKey;
    /** boss -> (joueur -> dégâts infligés) */
    private final Map<UUID, Map<UUID, Double>> damage = new HashMap<>();

    public BossManager(PowerSMP plugin) {
        this.plugin = plugin;
        this.bossKey = new NamespacedKey(plugin, "boss_id");
    }

    private ConfigurationSection cfg(String id) {
        return plugin.getConfig().getConfigurationSection("bosses." + id);
    }

    public boolean exists(String id) {
        return cfg(id) != null;
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("bosses");
        return s == null ? Set.of() : s.getKeys(false);
    }

    /** Nom brut (avec codes &). */
    public String getName(String id) {
        ConfigurationSection s = cfg(id);
        return s == null ? id : s.getString("name", id);
    }

    public String getBossId(Entity entity) {
        return entity.getPersistentDataContainer().get(bossKey, PersistentDataType.STRING);
    }

    /** Invoque un boss. Retourne null si la config est invalide. */
    public LivingEntity spawn(String id, Location loc) {
        ConfigurationSection s = cfg(id);
        if (s == null || loc.getWorld() == null) {
            return null;
        }
        EntityType type;
        try {
            type = EntityType.valueOf(s.getString("entity", "ZOMBIE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Boss " + id + " : type d'entité invalide.");
            return null;
        }
        Entity entity = loc.getWorld().spawnEntity(loc, type);
        if (!(entity instanceof LivingEntity boss)) {
            entity.remove();
            return null;
        }
        boss.customName(Text.c(s.getString("name", id)));
        boss.setCustomNameVisible(true);
        boss.setRemoveWhenFarAway(false);
        boss.setPersistent(true);
        boss.setGlowing(s.getBoolean("glowing", true));

        double health = s.getDouble("health", 100);
        AttributeInstance maxHealth = boss.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(health);
            boss.setHealth(Math.min(health, maxHealth.getValue()));
        }
        if (s.contains("attack-damage")) {
            AttributeInstance attack = boss.getAttribute(Attribute.ATTACK_DAMAGE);
            if (attack != null) {
                attack.setBaseValue(s.getDouble("attack-damage"));
            }
        }
        boss.getPersistentDataContainer().set(bossKey, PersistentDataType.STRING, id);
        return boss;
    }

    /** Enregistre les dégâts infligés à un boss par un joueur. */
    public void recordDamage(LivingEntity victim, Player damager, double amount) {
        if (getBossId(victim) == null) {
            return;
        }
        damage.computeIfAbsent(victim.getUniqueId(), k -> new HashMap<>())
                .merge(damager.getUniqueId(), amount, Double::sum);
    }

    /** Mort d'un boss : crédite les participants. Retourne true si l'entité était un boss. */
    public boolean handleDeath(EntityDeathEvent event) {
        LivingEntity victim = event.getEntity();
        String id = getBossId(victim);
        if (id == null) {
            return false;
        }
        ConfigurationSection s = cfg(id);
        Map<UUID, Double> dealt = damage.remove(victim.getUniqueId());
        if (s == null) {
            return true;
        }
        if (s.getBoolean("clear-vanilla-drops", true)) {
            event.getDrops().clear();
        }
        event.setDroppedExp(s.getInt("xp", 0));

        double health = s.getDouble("health", 100);
        double minFraction = plugin.getConfig().getDouble("boss-credit.min-damage-fraction", 0.05);

        Set<UUID> credited = new HashSet<>();
        if (dealt != null) {
            for (Map.Entry<UUID, Double> e : dealt.entrySet()) {
                if (e.getValue() >= health * minFraction) {
                    credited.add(e.getKey());
                }
            }
        }
        Player killer = victim.getKiller();
        if (killer != null) {
            credited.add(killer.getUniqueId());
        }

        for (UUID uuid : credited) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) {
                continue;
            }
            PlayerData data = plugin.getDataManager().get(p);
            if (data == null || !data.hasPower()) {
                continue;
            }
            data.addProgress("boss:" + id, 1);
            plugin.getMessages().send(p, "boss.defeated", "boss", getName(id));
            for (Map<?, ?> drop : s.getMapList("drops")) {
                Object item = drop.get("item");
                if (item == null || !plugin.getItems().exists(String.valueOf(item))) {
                    continue;
                }
                Object chanceObj = drop.get("chance");
                double chance = chanceObj instanceof Number n ? n.doubleValue() : 1.0;
                Object amountObj = drop.get("amount");
                int amount = amountObj instanceof Number n ? Math.max(1, n.intValue()) : 1;
                if (ThreadLocalRandom.current().nextDouble() <= chance) {
                    plugin.getItems().give(p, String.valueOf(item), amount);
                    plugin.getMessages().send(p, "boss.loot",
                            "item", plugin.getItems().getName(String.valueOf(item)), "amount", String.valueOf(amount));
                }
            }
            plugin.getDataManager().saveAsync(data);
        }
        return true;
    }

    public void shutdown() {
        damage.clear();
    }
}
