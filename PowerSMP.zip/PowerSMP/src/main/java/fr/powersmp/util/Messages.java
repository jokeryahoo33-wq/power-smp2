package fr.powersmp.util;

import fr.powersmp.PowerSMP;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Accès centralisé à messages.yml (tous les textes sont modifiables par l'admin). */
public final class Messages {

    private final PowerSMP plugin;
    private YamlConfiguration yaml = new YamlConfiguration();

    public Messages(PowerSMP plugin) {
        this.plugin = plugin;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        yaml = YamlConfiguration.loadConfiguration(file);
        // Valeurs par défaut du jar : une clé manquante dans le fichier de l'admin ne casse rien.
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                yaml.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException ignored) {
            // pas grave
        }
    }

    /** Texte brut (avec codes &) et placeholders remplacés. */
    public String raw(String key, String... kv) {
        String v = yaml.getString(key);
        if (v == null) {
            return "&c[message manquant : " + key + "]";
        }
        return Text.replace(v, kv);
    }

    public List<String> list(String key, String... kv) {
        List<String> out = new ArrayList<>();
        for (String s : yaml.getStringList(key)) {
            out.add(Text.replace(s, kv));
        }
        return out;
    }

    /** Message avec préfixe. */
    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(Text.c(raw("prefix") + raw(key, kv)));
    }

    /** Message sans préfixe. */
    public void sendRaw(CommandSender to, String key, String... kv) {
        to.sendMessage(Text.c(raw(key, kv)));
    }

    /** Liste de lignes sans préfixe. */
    public void sendLines(CommandSender to, String key, String... kv) {
        for (String line : list(key, kv)) {
            to.sendMessage(Text.c(line));
        }
    }

    public void actionBar(Player p, String key, String... kv) {
        p.sendActionBar(Text.c(raw(key, kv)));
    }
}
