package fr.powersmp.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Petits utilitaires de texte : couleurs (&a, &#RRGGBB), placeholders, formatage. */
public final class Text {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private Text() {
    }

    /** Convertit un texte avec codes couleur '&' en Component. */
    public static Component c(String s) {
        return LEGACY.deserialize(s == null ? "" : s);
    }

    /** Comme {@link #c(String)} mais sans l'italique par défaut des objets (noms/lores). */
    public static Component item(String s) {
        return c(s).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static List<Component> itemLines(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String l : lines) {
            out.add(item(l));
        }
        return out;
    }

    /** Remplace les {placeholders} par paires clé/valeur. */
    public static String replace(String s, String... kv) {
        if (s == null) {
            return "";
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1] == null ? "" : kv[i + 1]);
        }
        return s;
    }

    /** "DIAMOND_BLOCK" -> "Diamond Block". */
    public static String pretty(String raw) {
        if (raw == null || raw.isEmpty()) {
            return "";
        }
        String[] parts = raw.toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /** 8000 ms -> "8 secondes", 90000 ms -> "1 min 30 s". */
    public static String duration(long millis) {
        long total = Math.max(1, (millis + 999) / 1000);
        if (total < 60) {
            return total + (total == 1 ? " seconde" : " secondes");
        }
        long min = total / 60;
        long sec = total % 60;
        if (min >= 60) {
            long h = min / 60;
            min = min % 60;
            return h + " h " + min + " min";
        }
        return sec == 0 ? min + " min" : min + " min " + sec + " s";
    }
}
