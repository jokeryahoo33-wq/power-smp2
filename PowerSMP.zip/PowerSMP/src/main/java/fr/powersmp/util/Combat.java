package fr.powersmp.util;

import fr.powersmp.PowerSMP;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Outils de combat partagés par tous les pouvoirs (ciblage, dégâts, effets visuels). */
public final class Combat {

    private Combat() {
    }

    /** Une cible est valide si on a le droit de la blesser (PvP, mode de jeu, animaux apprivoisés, liste d'exclusion). */
    public static boolean isValidTarget(PowerSMP plugin, Player caster, LivingEntity target) {
        if (target.equals(caster) || target.isDead() || !target.isValid()) {
            return false;
        }
        if (target instanceof ArmorStand) {
            return false;
        }
        if (plugin.getConfig().getStringList("combat.ignored-entities").contains(target.getType().name())) {
            return false;
        }
        if (target instanceof Player victim) {
            if (!plugin.getConfig().getBoolean("combat.damage-players", true)) {
                return false;
            }
            if (!victim.getWorld().getPVP()) {
                return false;
            }
            GameMode gm = victim.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) {
                return false;
            }
        }
        if (target instanceof Tameable tame && tame.isTamed() && tame.getOwner() != null
                && tame.getOwner().getUniqueId().equals(caster.getUniqueId())) {
            return false;
        }
        return true;
    }

    /** Cible visée (rayon depuis les yeux), sans traverser les blocs. Null si rien. */
    public static LivingEntity findTarget(PowerSMP plugin, Player caster, double range) {
        Location eye = caster.getEyeLocation();
        Vector dir = eye.getDirection();
        World world = caster.getWorld();
        RayTraceResult hit = world.rayTraceEntities(eye, dir, range, 0.6,
                e -> e instanceof LivingEntity le && isValidTarget(plugin, caster, le));
        if (hit == null || !(hit.getHitEntity() instanceof LivingEntity target)) {
            return null;
        }
        RayTraceResult block = world.rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        if (block != null && block.getHitPosition() != null && hit.getHitPosition() != null) {
            double blockDist = eye.toVector().distance(block.getHitPosition());
            double entityDist = eye.toVector().distance(hit.getHitPosition());
            if (blockDist < entityDist) {
                return null;
            }
        }
        return target;
    }

    /** Point regardé (premier bloc touché) ou point au bout de la portée. */
    public static Location lookPoint(Player caster, double range) {
        Location eye = caster.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult hit = caster.getWorld().rayTraceBlocks(eye, dir, range, FluidCollisionMode.NEVER, true);
        if (hit != null && hit.getHitPosition() != null) {
            return hit.getHitPosition().toLocation(caster.getWorld());
        }
        return eye.clone().add(dir.clone().multiply(range));
    }

    /** Cibles valides autour d'un point. */
    public static List<LivingEntity> nearby(PowerSMP plugin, Player caster, Location center, double radius) {
        List<LivingEntity> result = new ArrayList<>();
        if (center.getWorld() == null) {
            return result;
        }
        for (LivingEntity le : center.getWorld().getNearbyLivingEntities(center, radius)) {
            if (!isValidTarget(plugin, caster, le)) {
                continue;
            }
            if (le.getBoundingBox().getCenter().distance(center.toVector()) <= radius + 0.5) {
                result.add(le);
            }
        }
        return result;
    }

    public static void damage(Player caster, LivingEntity target, double amount) {
        if (amount > 0) {
            target.damage(amount, caster);
        }
    }

    /** Éclair purement visuel + son : ne met pas le feu et ne casse rien (compatible CoreProtect/protections). */
    public static void bolt(Location loc) {
        if (loc.getWorld() != null) {
            loc.getWorld().strikeLightningEffect(loc);
        }
    }

    /** Point aléatoire dans un disque horizontal autour de center. */
    public static Location randomAround(Location center, double radius) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double angle = rnd.nextDouble() * Math.PI * 2;
        double r = radius * Math.sqrt(rnd.nextDouble());
        return center.clone().add(Math.cos(angle) * r, 0, Math.sin(angle) * r);
    }

    /** Ligne d'étincelles entre deux points (effet visuel des chaînes). */
    public static void line(Location a, Location b) {
        World w = a.getWorld();
        if (w == null || !w.equals(b.getWorld())) {
            return;
        }
        Vector dir = b.toVector().subtract(a.toVector());
        double len = Math.min(dir.length(), 40);
        if (len < 0.1) {
            return;
        }
        dir.normalize().multiply(0.5);
        Location cur = a.clone();
        for (double d = 0; d < len; d += 0.5) {
            w.spawnParticle(Particle.ELECTRIC_SPARK, cur, 2, 0.05, 0.05, 0.05, 0);
            cur.add(dir);
        }
    }
}
