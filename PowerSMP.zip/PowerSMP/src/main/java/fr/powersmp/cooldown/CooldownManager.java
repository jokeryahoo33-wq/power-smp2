package fr.powersmp.cooldown;

import fr.powersmp.data.PlayerData;

/** Cooldowns par capacité. Stockés dans PlayerData (donc persistés : relog ou restart ne les remet pas à zéro). */
public final class CooldownManager {

    /** Millisecondes restantes (0 si prêt). */
    public long remaining(PlayerData data, String key) {
        long expiry = data.getCooldownExpiry(key);
        if (expiry <= 0) {
            return 0;
        }
        long left = expiry - System.currentTimeMillis();
        if (left <= 0) {
            data.removeCooldown(key);
            return 0;
        }
        return left;
    }

    public void start(PlayerData data, String key, long millis) {
        data.setCooldownExpiry(key, System.currentTimeMillis() + millis);
    }
}
