package fr.powersmp.power;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.lightning.LightningPower;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Registre des pouvoirs + logique commune : attribution, sélection et lancement des capacités. */
public final class PowerManager {

    private final PowerSMP plugin;
    private final Map<String, Power> powers = new LinkedHashMap<>();

    public PowerManager(PowerSMP plugin) {
        this.plugin = plugin;
        // >>> Pour ajouter un pouvoir : register(new FirePower(plugin)); <<<
        register(new LightningPower(plugin));
    }

    public void register(Power power) {
        powers.put(power.getId(), power);
    }

    /** Pouvoir implémenté en code (null si inconnu ou pas encore codé). */
    public Power get(String id) {
        return id == null ? null : powers.get(id);
    }

    /** Tous les pouvoirs décrits dans config.yml (même ceux pas encore codés : ils s'affichent "bientôt"). */
    public Set<String> configuredIds() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("powers");
        return s == null ? Collections.emptySet() : s.getKeys(false);
    }

    /** Un pouvoir est choisissable s'il est codé ET activé dans la config. */
    public boolean isSelectable(String id) {
        Power p = get(id);
        return p != null && p.isEnabled();
    }

    public String name(String id) {
        return plugin.getConfig().getString("powers." + id + ".name", id);
    }

    public String symbol(String id) {
        return plugin.getConfig().getString("powers." + id + ".symbol", "*");
    }

    public String color(String id) {
        return plugin.getConfig().getString("powers." + id + ".color", "&f");
    }

    // ------------------------------------------------------------------ attribution

    /** Donne un pouvoir : grade F, progression remise à zéro, anciennes capacités en cours annulées. */
    public void assign(PlayerData data, String powerId) {
        data.setPowerId(powerId);
        data.setGrade(Grade.F);
        data.clearProgress();
        data.bumpEpoch();
        data.setSelectedAbility(null);
        plugin.getTrials().cancel(data.getUuid(), "trial.failed-changed");
        plugin.getDataManager().saveAsync(data);
    }

    /** Retire le pouvoir, le grade, la progression et les cooldowns. */
    public void reset(PlayerData data) {
        data.setPowerId(null);
        data.setGrade(Grade.F);
        data.clearProgress();
        data.clearCooldowns();
        data.bumpEpoch();
        data.setSelectedAbility(null);
        plugin.getTrials().cancel(data.getUuid(), "trial.failed-changed");
        plugin.getDataManager().saveAsync(data);
    }

    // ------------------------------------------------------------------ capacités

    public List<Ability> unlocked(PlayerData data) {
        Power power = get(data.getPowerId());
        return power == null ? Collections.emptyList() : power.getUnlocked(data.getGrade());
    }

    /** Capacité sélectionnée (la première débloquée par défaut). Null si aucune. */
    public Ability selected(PlayerData data) {
        List<Ability> list = unlocked(data);
        if (list.isEmpty()) {
            return null;
        }
        String sel = data.getSelectedAbility();
        if (sel != null) {
            for (Ability a : list) {
                if (a.getId().equals(sel)) {
                    return a;
                }
            }
        }
        return list.get(0);
    }

    /** Sélectionne une capacité par id ou par nom (insensible à la casse). */
    public boolean select(Player player, PlayerData data, String query) {
        for (Ability a : unlocked(data)) {
            if (a.getId().equalsIgnoreCase(query) || stripColors(a.getName()).equalsIgnoreCase(query)) {
                data.setSelectedAbility(a.getId());
                showSelected(player, data);
                return true;
            }
        }
        return false;
    }

    /** Passe à la capacité suivante (dir = 1) ou précédente (dir = -1). */
    public void cycle(Player player, int dir) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            return;
        }
        List<Ability> list = unlocked(data);
        if (list.isEmpty()) {
            return;
        }
        Ability current = selected(data);
        int index = Math.max(0, list.indexOf(current));
        index = ((index + dir) % list.size() + list.size()) % list.size();
        data.setSelectedAbility(list.get(index).getId());
        showSelected(player, data);
    }

    public void showSelected(Player player, PlayerData data) {
        Ability a = selected(data);
        Power power = get(data.getPowerId());
        if (a == null || power == null) {
            return;
        }
        long left = plugin.getCooldowns().remaining(data, a.getKey());
        String state = left > 0
                ? plugin.getMessages().raw("cast.state-cooldown", "time", Text.duration(left))
                : plugin.getMessages().raw("cast.state-ready");
        plugin.getMessages().actionBar(player, "cast.selected",
                "color", power.getColor(), "symbol", power.getSymbol(),
                "ability", a.getName(), "state", state);
    }

    /** Lance la capacité sélectionnée, après toutes les vérifications (permission, monde, grade, cooldown, spam). */
    public void cast(Player player) {
        Messages m = plugin.getMessages();
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null || !data.hasPower()) {
            m.actionBar(player, "cast.no-power");
            return;
        }
        if (!player.hasPermission("powersmp.use")) {
            m.actionBar(player, "cast.no-permission");
            return;
        }
        if (plugin.getConfig().getStringList("disabled-worlds").contains(player.getWorld().getName())) {
            m.actionBar(player, "cast.disabled-world");
            return;
        }
        Power power = get(data.getPowerId());
        if (power == null || !power.isEnabled()) {
            m.actionBar(player, "cast.power-disabled");
            return;
        }
        Ability ability = selected(data);
        // Vérification explicite : le pouvoir du joueur et le grade doivent permettre cette capacité.
        if (ability == null || !ability.getPower().getId().equals(data.getPowerId())
                || !data.getGrade().isAtLeast(ability.getUnlockGrade())) {
            m.actionBar(player, "cast.locked");
            return;
        }
        // Anti-spam global (évite le double déclenchement et le martelage de touche).
        long now = System.nanoTime();
        long minGap = plugin.getConfig().getLong("controls.global-cast-delay-ms", 400) * 1_000_000L;
        if (now - data.getLastCastNanos() < minGap) {
            return;
        }
        data.setLastCastNanos(now);

        long left = plugin.getCooldowns().remaining(data, ability.getKey());
        if (left > 0) {
            m.actionBar(player, "cast.cooldown",
                    "color", power.getColor(), "symbol", power.getSymbol(), "power", power.getName(),
                    "ability", ability.getName(), "time", Text.duration(left));
            return;
        }
        if (ability.cast(player, data)) {
            plugin.getCooldowns().start(data, ability.getKey(), ability.getCooldownMillis());
        }
    }

    private static String stripColors(String s) {
        return s == null ? "" : s.replaceAll("(?i)&[0-9a-fk-or]|&#[0-9a-f]{6}", "");
    }
}
