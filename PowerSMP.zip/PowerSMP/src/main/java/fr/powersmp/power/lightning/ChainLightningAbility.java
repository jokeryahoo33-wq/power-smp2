package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Power;
import fr.powersmp.util.Combat;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * C Chaîne : la foudre saute de cible en cible (3 par défaut), avec dégâts décroissants.
 * Config : range, max-targets, chain-radius, damage, damage-falloff, jump-delay-ticks.
 */
public final class ChainLightningAbility extends Ability {

    public ChainLightningAbility(PowerSMP plugin, Power power, String id) {
        super(plugin, power, id);
    }

    @Override
    public boolean cast(Player player, PlayerData data) {
        ConfigurationSection c = cfg();
        double range = c.getDouble("range", 25);
        int maxTargets = Math.max(1, c.getInt("max-targets", 3));
        double chainRadius = c.getDouble("chain-radius", 8);
        double damage = c.getDouble("damage", 6);
        double falloff = c.getDouble("damage-falloff", 0.8);
        long delay = Math.max(1, c.getLong("jump-delay-ticks", 4));

        LivingEntity first = Combat.findTarget(plugin, player, range);
        if (first == null) {
            plugin.getMessages().actionBar(player, "cast.no-target");
            return false;
        }

        // Construit la chaîne : chaque maillon est la cible valide la plus proche du précédent.
        List<LivingEntity> chain = new ArrayList<>();
        chain.add(first);
        while (chain.size() < maxTargets) {
            LivingEntity last = chain.get(chain.size() - 1);
            LivingEntity best = null;
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity candidate : Combat.nearby(plugin, player, last.getLocation(), chainRadius)) {
                if (chain.contains(candidate)) {
                    continue;
                }
                double dist = candidate.getLocation().distanceSquared(last.getLocation());
                if (dist < bestDist) {
                    bestDist = dist;
                    best = candidate;
                }
            }
            if (best == null) {
                break;
            }
            chain.add(best);
        }

        final int epoch = data.getEpoch();
        for (int i = 0; i < chain.size(); i++) {
            final int index = i;
            final LivingEntity victim = chain.get(i);
            final Location from = i == 0 ? player.getEyeLocation() : chain.get(i - 1).getLocation().add(0, 1, 0);
            Runnable strike = () -> {
                if (!stillActive(player, data, epoch) || !victim.isValid() || victim.isDead()) {
                    return;
                }
                Combat.line(from, victim.getLocation().add(0, 1, 0));
                Combat.bolt(victim.getLocation());
                Combat.damage(player, victim, damage * Math.pow(falloff, index));
            };
            if (i == 0) {
                strike.run();
            } else {
                plugin.getServer().getScheduler().runTaskLater(plugin, strike, delay * i);
            }
        }
        return true;
    }
}
