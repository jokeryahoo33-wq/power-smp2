package fr.powersmp.power;

import java.util.Locale;

/** Grades de F (départ) à SSS (maximum). */
public enum Grade {
    F, E, D, C, B, A, S, SS, SSS;

    /** Grade suivant, ou null si on est déjà au maximum. */
    public Grade next() {
        Grade[] all = values();
        return ordinal() + 1 < all.length ? all[ordinal() + 1] : null;
    }

    public boolean isAtLeast(Grade other) {
        return ordinal() >= other.ordinal();
    }

    /** Null si le texte n'est pas un grade valide. */
    public static Grade parse(String s) {
        if (s == null) {
            return null;
        }
        try {
            return valueOf(s.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
