package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Power;
import fr.powersmp.util.Combat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * D Frappe : cible un joueur/mob à longue distance. Sans cible visée, rien ne se passe (pas de cooldown).
 * Config : range, damage.
 */
public final class TargetStrikeAbility extends Ability {

    public TargetStrikeAbility(PowerSMP plugin, Power power, String id) {
        super(plugin, power, id);
    }

    @Override
    public boolean cast(Player player, PlayerData data) {
        ConfigurationSection c = cfg();
        double range = c.getDouble("range", 30);
        double damage = c.getDouble("damage", 8);

        LivingEntity target = Combat.findTarget(plugin, player, range);
        if (target == null) {
            plugin.getMessages().actionBar(player, "cast.no-target");
            return false;
        }
        Combat.bolt(target.getLocation());
        Combat.damage(player, target, damage);
        return true;
    }
}
