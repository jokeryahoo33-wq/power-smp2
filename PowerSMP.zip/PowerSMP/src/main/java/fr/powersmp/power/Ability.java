package fr.powersmp.power;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;
import org.bukkit.entity.Player;

/**
 * Une capacité. Toutes ses valeurs (nom, grade requis, cooldown, dégâts...) sont lues dans
 * config.yml sous powers.&lt;pouvoir&gt;.abilities.&lt;id&gt; : /powersmp reload suffit à les modifier.
 */
public abstract class Ability {

    protected final PowerSMP plugin;
    protected final Power power;
    private final String id;

    protected Ability(PowerSMP plugin, Power power, String id) {
        this.plugin = plugin;
        this.power = power;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public Power getPower() {
        return power;
    }

    /** Clé unique utilisée pour les cooldowns (ex. "lightning:spark"). */
    public String getKey() {
        return power.getId() + ":" + id;
    }

    protected ConfigurationSection cfg() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection(
                "powers." + power.getId() + ".abilities." + id);
        return s != null ? s : new MemoryConfiguration();
    }

    public String getName() {
        return cfg().getString("name", id);
    }

    public String getDescription() {
        return cfg().getString("description", "");
    }

    public Grade getUnlockGrade() {
        Grade g = Grade.parse(cfg().getString("unlock-grade", "F"));
        return g == null ? Grade.F : g;
    }

    public long getCooldownMillis() {
        return (long) (cfg().getDouble("cooldown", 30) * 1000L);
    }

    /** Vrai si la tâche lancée par une capacité doit continuer (le joueur n'a pas changé de pouvoir, n'est pas mort, etc.). */
    protected boolean stillActive(Player player, PlayerData data, int epoch) {
        return player.isOnline() && !player.isDead()
                && data.getEpoch() == epoch
                && power.getId().equals(data.getPowerId());
    }

    /**
     * Lance la capacité. Retourne true si elle a été réellement utilisée (le cooldown démarre alors),
     * false si elle n'a rien fait (ex. aucune cible) : dans ce cas aucun cooldown n'est appliqué.
     */
    public abstract boolean cast(Player player, PlayerData data);
}
