package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Power;
import fr.powersmp.util.Combat;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Zone de foudre pendant quelques secondes (A Tempête, S Orage, SSS Apocalypse).
 * Config : range, center (LOOK ou SELF), radius, hit-radius, damage, duration-seconds,
 *          interval-ticks, bolts-per-interval.
 */
public final class StormZoneAbility extends Ability {

    public StormZoneAbility(PowerSMP plugin, Power power, String id) {
        super(plugin, power, id);
    }

    @Override
    public boolean cast(Player player, PlayerData data) {
        ConfigurationSection c = cfg();
        double range = c.getDouble("range", 30);
        boolean onSelf = "SELF".equalsIgnoreCase(c.getString("center", "LOOK"));
        double radius = c.getDouble("radius", 8);
        double hitRadius = c.getDouble("hit-radius", 2);
        double damage = c.getDouble("damage", 3);
        int durationTicks = Math.max(1, c.getInt("duration-seconds", 6)) * 20;
        int interval = Math.max(2, c.getInt("interval-ticks", 10));          // minimum 2 ticks : protège le serveur
        int boltsPerInterval = Math.max(1, Math.min(c.getInt("bolts-per-interval", 2), 10));

        Location center = onSelf ? player.getLocation().clone() : Combat.lookPoint(player, range);

        final int epoch = data.getEpoch();
        new BukkitRunnable() {
            private int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= durationTicks || !stillActive(player, data, epoch)) {
                    cancel();
                    return;
                }
                for (int i = 0; i < boltsPerInterval; i++) {
                    Location impact = Combat.randomAround(center, radius);
                    Combat.bolt(impact);
                    for (LivingEntity victim : Combat.nearby(plugin, player, impact, hitRadius)) {
                        Combat.damage(player, victim, damage);
                    }
                }
                elapsed += interval;
            }
        }.runTaskTimer(plugin, 0L, interval);
        return true;
    }
}
