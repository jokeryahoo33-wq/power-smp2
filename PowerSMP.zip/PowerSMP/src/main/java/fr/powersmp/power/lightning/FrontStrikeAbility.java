package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Power;
import fr.powersmp.util.Combat;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Éclair devant soi (F Étincelle, E Décharge) : frappe l'entité visée si il y en a une,
 * sinon le point regardé, et blesse tout ce qui est dans le rayon.
 * Config : range, radius, damage.
 */
public final class FrontStrikeAbility extends Ability {

    public FrontStrikeAbility(PowerSMP plugin, Power power, String id) {
        super(plugin, power, id);
    }

    @Override
    public boolean cast(Player player, PlayerData data) {
        ConfigurationSection c = cfg();
        double range = c.getDouble("range", 6);
        double radius = c.getDouble("radius", 1.5);
        double damage = c.getDouble("damage", 4);

        LivingEntity target = Combat.findTarget(plugin, player, range);
        Location impact = target != null ? target.getLocation() : Combat.lookPoint(player, range);

        Combat.bolt(impact);
        for (LivingEntity victim : Combat.nearby(plugin, player, impact, radius)) {
            Combat.damage(player, victim, damage);
        }
        return true;
    }
}
