package fr.powersmp.power;

import fr.powersmp.PowerSMP;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Un pouvoir (Lightning, Fire...). Pour en ajouter un : créer une sous-classe, y enregistrer ses capacités,
 * puis l'enregistrer dans {@link PowerManager}. Les textes/icônes/valeurs vivent dans config.yml.
 */
public abstract class Power {

    protected final PowerSMP plugin;
    private final String id;
    private final Map<String, Ability> abilities = new LinkedHashMap<>();

    protected Power(PowerSMP plugin, String id) {
        this.plugin = plugin;
        this.id = id;
    }

    protected void register(Ability ability) {
        abilities.put(ability.getId(), ability);
    }

    public String getId() {
        return id;
    }

    public ConfigurationSection cfg() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("powers." + id);
        return s != null ? s : new MemoryConfiguration();
    }

    public boolean isEnabled() {
        return cfg().getBoolean("enabled", false);
    }

    public String getName() {
        return cfg().getString("name", id);
    }

    public String getSymbol() {
        return cfg().getString("symbol", "*");
    }

    public String getColor() {
        return cfg().getString("color", "&f");
    }

    public Collection<Ability> getAbilities() {
        return Collections.unmodifiableCollection(abilities.values());
    }

    public Ability getAbility(String abilityId) {
        return abilities.get(abilityId);
    }

    /** Capacités débloquées au grade donné, dans l'ordre d'enregistrement. */
    public List<Ability> getUnlocked(Grade grade) {
        List<Ability> list = new ArrayList<>();
        for (Ability a : abilities.values()) {
            if (grade.isAtLeast(a.getUnlockGrade())) {
                list.add(a);
            }
        }
        return list;
    }
}
