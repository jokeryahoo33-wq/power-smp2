package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.power.Power;

/**
 * Pouvoir Lightning. Neuf capacités (une par grade de F à SSS) construites à partir de 5 "briques"
 * paramétrées par config.yml : on peut changer leurs valeurs sans toucher au code.
 */
public final class LightningPower extends Power {

    public LightningPower(PowerSMP plugin) {
        super(plugin, "lightning");
        register(new FrontStrikeAbility(plugin, this, "spark"));        // F  - Étincelle
        register(new FrontStrikeAbility(plugin, this, "discharge"));    // E  - Décharge
        register(new TargetStrikeAbility(plugin, this, "strike"));      // D  - Frappe
        register(new ChainLightningAbility(plugin, this, "chain"));     // C  - Chaîne
        register(new ThunderAbility(plugin, this, "thunder"));          // B  - Tonnerre
        register(new StormZoneAbility(plugin, this, "storm"));          // A  - Tempête
        register(new StormZoneAbility(plugin, this, "thunderstorm"));   // S  - Orage
        register(new ThunderAbility(plugin, this, "god"));              // SS - Dieu de la Foudre
        register(new StormZoneAbility(plugin, this, "apocalypse"));     // SSS - Apocalypse
    }
}
