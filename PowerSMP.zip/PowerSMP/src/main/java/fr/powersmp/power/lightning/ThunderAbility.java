package fr.powersmp.power.lightning;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Power;
import fr.powersmp.util.Combat;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Plusieurs éclairs autour d'une cible (B Tonnerre, SS Dieu de la Foudre), avec bonus de vitesse optionnel.
 * Config : range, bolts, radius, hit-radius, damage, bolt-delay-ticks,
 *          speed-amplifier (-1 = aucun bonus), speed-duration-seconds.
 */
public final class ThunderAbility extends Ability {

    public ThunderAbility(PowerSMP plugin, Power power, String id) {
        super(plugin, power, id);
    }

    @Override
    public boolean cast(Player player, PlayerData data) {
        ConfigurationSection c = cfg();
        double range = c.getDouble("range", 30);
        int bolts = Math.max(1, Math.min(c.getInt("bolts", 5), 30));
        double spread = c.getDouble("radius", 5);
        double hitRadius = c.getDouble("hit-radius", 1.5);
        double damage = c.getDouble("damage", 5);
        long delay = Math.max(1, c.getLong("bolt-delay-ticks", 5));

        LivingEntity target = Combat.findTarget(plugin, player, range);
        Location center = target != null ? target.getLocation() : Combat.lookPoint(player, range);

        int speedAmp = c.getInt("speed-amplifier", -1);
        if (speedAmp >= 0) {
            int ticks = Math.max(1, c.getInt("speed-duration-seconds", 10)) * 20;
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, ticks, speedAmp, false, true, true));
        }

        final int epoch = data.getEpoch();
        new BukkitRunnable() {
            private int fired = 0;

            @Override
            public void run() {
                if (fired >= bolts || !stillActive(player, data, epoch)) {
                    cancel();
                    return;
                }
                // Le premier éclair touche directement la cible, les autres tombent autour.
                Location impact = (fired == 0 && target != null && target.isValid())
                        ? target.getLocation()
                        : Combat.randomAround(center, spread);
                Combat.bolt(impact);
                for (LivingEntity victim : Combat.nearby(plugin, player, impact, hitRadius)) {
                    Combat.damage(player, victim, damage);
                }
                fired++;
            }
        }.runTaskTimer(plugin, 0L, delay);
        return true;
    }
}
