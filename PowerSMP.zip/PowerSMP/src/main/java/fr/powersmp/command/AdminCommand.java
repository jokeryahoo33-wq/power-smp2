package fr.powersmp.command;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Grade;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** /powersmp : administration. */
public final class AdminCommand implements TabExecutor {

    private final PowerSMP plugin;

    public AdminCommand(PowerSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages m = plugin.getMessages();
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);

        boolean admin = sender.hasPermission("powersmp.admin");
        if (sub.equals("reload")) {
            if (!admin && !sender.hasPermission("powersmp.reload")) {
                m.send(sender, "no-permission");
                return true;
            }
            plugin.reloadPlugin();
            m.send(sender, "admin.reloaded");
            return true;
        }
        if (!admin) {
            m.send(sender, "no-permission");
            return true;
        }

        switch (sub) {
            case "give" -> give(sender, args);
            case "setgrade" -> setGrade(sender, args);
            case "reset" -> reset(sender, args);
            case "info" -> info(sender, args);
            case "item" -> item(sender, args);
            case "boss" -> boss(sender, args);
            case "sanctuary" -> sanctuary(sender, args);
            default -> m.sendLines(sender, "admin.help");
        }
        return true;
    }

    private Player target(CommandSender sender, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) {
            plugin.getMessages().send(sender, "admin.player-offline", "player", name);
        }
        return p;
    }

    // /powersmp give <joueur> <pouvoir>
    private void give(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (args.length < 3) {
            m.send(sender, "admin.usage-give");
            return;
        }
        Player target = target(sender, args[1]);
        PlayerData data = target == null ? null : plugin.getDataManager().get(target);
        if (data == null) {
            return;
        }
        String powerId = args[2].toLowerCase(Locale.ROOT);
        if (!plugin.getPowers().isSelectable(powerId)) {
            m.send(sender, "admin.unknown-power", "power", args[2]);
            return;
        }
        plugin.getPowers().assign(data, powerId);
        String display = plugin.getPowers().color(powerId) + plugin.getPowers().name(powerId);
        m.send(sender, "admin.given", "player", target.getName(), "power", display);
        m.send(target, "admin.received", "power", display);
    }

    // /powersmp setgrade <joueur> <grade>
    private void setGrade(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (args.length < 3) {
            m.send(sender, "admin.usage-setgrade");
            return;
        }
        Player target = target(sender, args[1]);
        PlayerData data = target == null ? null : plugin.getDataManager().get(target);
        if (data == null) {
            return;
        }
        if (!data.hasPower()) {
            m.send(sender, "admin.no-power", "player", target.getName());
            return;
        }
        Grade grade = Grade.parse(args[2]);
        if (grade == null) {
            m.send(sender, "admin.unknown-grade", "grade", args[2]);
            return;
        }
        data.setGrade(grade);
        data.setSelectedAbility(null);
        plugin.getDataManager().saveAsync(data);
        m.send(sender, "admin.grade-set", "player", target.getName(), "grade", plugin.gradeLabel(grade));
        m.send(target, "admin.grade-received", "grade", plugin.gradeLabel(grade));
    }

    // /powersmp reset <joueur>
    private void reset(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (args.length < 2) {
            m.send(sender, "admin.usage-reset");
            return;
        }
        Player target = target(sender, args[1]);
        PlayerData data = target == null ? null : plugin.getDataManager().get(target);
        if (data == null) {
            return;
        }
        plugin.getPowers().reset(data);
        m.send(sender, "admin.reset", "player", target.getName());
        m.send(target, "admin.reset-received");
    }

    // /powersmp info <joueur>
    private void info(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (args.length < 2) {
            m.send(sender, "admin.usage-info");
            return;
        }
        Player target = target(sender, args[1]);
        PlayerData data = target == null ? null : plugin.getDataManager().get(target);
        if (data == null) {
            return;
        }
        m.sendRaw(sender, "admin.info.header", "player", target.getName());
        m.sendRaw(sender, "admin.info.uuid", "uuid", data.getUuid().toString());
        m.sendRaw(sender, "admin.info.power", "power", data.hasPower() ? data.getPowerId() : "-");
        m.sendRaw(sender, "admin.info.grade", "grade", plugin.gradeLabel(data.getGrade()));
        if (data.getProgressMap().isEmpty()) {
            m.sendRaw(sender, "admin.info.progress-none");
        } else {
            for (Map.Entry<String, Integer> e : data.getProgressMap().entrySet()) {
                m.sendRaw(sender, "admin.info.progress", "key", e.getKey(), "value", String.valueOf(e.getValue()));
            }
        }
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> e : data.getCooldownMap().entrySet()) {
            if (e.getValue() > now) {
                m.sendRaw(sender, "admin.info.cooldown", "key", e.getKey(), "time", Text.duration(e.getValue() - now));
            }
        }
    }

    // /powersmp item give <joueur> <objet> [quantité]
    private void item(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (args.length < 4 || !args[1].equalsIgnoreCase("give")) {
            m.send(sender, "admin.usage-item");
            return;
        }
        Player target = target(sender, args[2]);
        if (target == null) {
            return;
        }
        String id = args[3].toLowerCase(Locale.ROOT);
        if (!plugin.getItems().exists(id)) {
            m.send(sender, "admin.unknown-item", "item", args[3]);
            return;
        }
        int amount = 1;
        if (args.length >= 5) {
            try {
                amount = Math.max(1, Math.min(Integer.parseInt(args[4]), 64 * 36));
            } catch (NumberFormatException e) {
                m.send(sender, "admin.usage-item");
                return;
            }
        }
        plugin.getItems().give(target, id, amount);
        m.send(sender, "admin.item-given", "player", target.getName(), "amount", String.valueOf(amount),
                "item", plugin.getItems().getName(id));
    }

    // /powersmp boss spawn <boss>
    private void boss(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (!(sender instanceof Player player)) {
            m.send(sender, "players-only");
            return;
        }
        if (args.length < 3 || !args[1].equalsIgnoreCase("spawn")) {
            m.send(sender, "admin.usage-boss");
            return;
        }
        String id = args[2].toLowerCase(Locale.ROOT);
        if (!plugin.getBosses().exists(id)) {
            m.send(sender, "admin.unknown-boss", "boss", args[2]);
            return;
        }
        LivingEntity boss = plugin.getBosses().spawn(id, player.getLocation());
        if (boss == null) {
            m.send(sender, "admin.boss-failed");
            return;
        }
        m.send(sender, "admin.boss-spawned", "boss", plugin.getBosses().getName(id));
    }

    // /powersmp sanctuary set <épreuve>
    private void sanctuary(CommandSender sender, String[] args) {
        Messages m = plugin.getMessages();
        if (!(sender instanceof Player player)) {
            m.send(sender, "players-only");
            return;
        }
        if (args.length < 3 || !args[1].equalsIgnoreCase("set")) {
            m.send(sender, "admin.usage-sanctuary");
            return;
        }
        String id = args[2].toLowerCase(Locale.ROOT);
        if (!plugin.getTrials().exists(id)) {
            m.send(sender, "admin.unknown-trial", "trial", args[2]);
            return;
        }
        plugin.getTrials().setSanctuary(id, player.getLocation());
        m.send(sender, "admin.sanctuary-set", "trial", plugin.getTrials().getName(id));
    }

    // ------------------------------------------------------------------ tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("powersmp.admin")) {
            return sender.hasPermission("powersmp.reload") && args.length == 1
                    ? PowerCommand.filter(List.of("reload"), args[0]) : List.of();
        }
        if (args.length == 1) {
            return PowerCommand.filter(List.of("reload", "give", "setgrade", "reset", "info", "item", "boss", "sanctuary"), args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            switch (sub) {
                case "give", "setgrade", "reset", "info" -> {
                    return PowerCommand.filter(onlineNames(), args[1]);
                }
                case "item" -> {
                    return PowerCommand.filter(List.of("give"), args[1]);
                }
                case "boss" -> {
                    return PowerCommand.filter(List.of("spawn"), args[1]);
                }
                case "sanctuary" -> {
                    return PowerCommand.filter(List.of("set"), args[1]);
                }
                default -> {
                    return List.of();
                }
            }
        }
        if (args.length == 3) {
            switch (sub) {
                case "give" -> {
                    return PowerCommand.filter(new ArrayList<>(plugin.getPowers().configuredIds()), args[2]);
                }
                case "setgrade" -> {
                    return PowerCommand.filter(Arrays.stream(Grade.values()).map(Grade::name).toList(), args[2]);
                }
                case "item" -> {
                    return PowerCommand.filter(onlineNames(), args[2]);
                }
                case "boss" -> {
                    return PowerCommand.filter(new ArrayList<>(plugin.getBosses().ids()), args[2]);
                }
                case "sanctuary" -> {
                    return PowerCommand.filter(new ArrayList<>(plugin.getTrials().ids()), args[2]);
                }
                default -> {
                    return List.of();
                }
            }
        }
        if (args.length == 4 && sub.equals("item")) {
            return PowerCommand.filter(new ArrayList<>(plugin.getItems().ids()), args[3]);
        }
        return List.of();
    }

    private List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            names.add(p.getName());
        }
        return names;
    }
}
