package fr.powersmp.command;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.evolution.EvolutionManager;
import fr.powersmp.gui.GuiManager;
import fr.powersmp.power.Ability;
import fr.powersmp.power.Grade;
import fr.powersmp.power.Power;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/** /power : commande joueur. */
public final class PowerCommand implements TabExecutor {

    private final PowerSMP plugin;

    public PowerCommand(PowerSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages m = plugin.getMessages();
        if (!(sender instanceof Player player)) {
            m.send(sender, "players-only");
            return true;
        }
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            m.send(player, "data-not-loaded");
            return true;
        }
        String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "choose" -> {
                if (!player.hasPermission("powersmp.choose")) {
                    m.send(player, "no-permission");
                } else if (data.hasPower()) {
                    m.send(player, "choose.already");
                } else {
                    plugin.getGui().openSelect(player, GuiManager.Mode.CHOOSE);
                }
            }
            case "switch" -> {
                if (!player.hasPermission("powersmp.switch")) {
                    m.send(player, "no-permission");
                } else if (!data.hasPower()) {
                    m.send(player, "switch.no-power");
                } else {
                    plugin.getGui().openSelect(player, GuiManager.Mode.SWITCH);
                }
            }
            default -> {
                if (!player.hasPermission("powersmp.use")) {
                    m.send(player, "no-permission");
                    return true;
                }
                switch (sub) {
                    case "status" -> status(player, data);
                    case "info" -> info(player, data);
                    case "abilities" -> abilities(player, data);
                    case "evolve" -> evolve(player, data);
                    case "select" -> select(player, data, args);
                    case "trial" -> {
                        if (args.length < 2) {
                            m.send(player, "trial.usage");
                        } else {
                            plugin.getTrials().start(player, data, args[1].toLowerCase(Locale.ROOT));
                        }
                    }
                    default -> m.sendLines(player, "help");
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ /power

    private void status(Player player, PlayerData data) {
        Messages m = plugin.getMessages();
        Power power = plugin.getPowers().get(data.getPowerId());
        if (!data.hasPower() || power == null) {
            m.send(player, "status.no-power");
            return;
        }
        String color = power.getColor();
        String symbol = power.getSymbol();
        String abilities = power.getUnlocked(data.getGrade()).stream()
                .map(Ability::getName)
                .collect(Collectors.joining("&7, &f"));

        m.sendRaw(player, "status.header");
        m.sendRaw(player, "status.power", "color", color, "symbol", symbol, "power", power.getName());
        m.sendRaw(player, "status.grade", "grade", plugin.gradeLabel(data.getGrade()));
        m.sendRaw(player, "status.abilities", "color", color, "symbol", symbol, "abilities", "&f" + abilities);

        Grade next = data.getGrade().next();
        if (next == null) {
            m.sendRaw(player, "status.max");
            return;
        }
        m.sendRaw(player, "status.next", "next", plugin.gradeLabel(next));
        m.sendRaw(player, "status.conditions");
        List<EvolutionManager.Requirement> reqs = plugin.getEvolution().getRequirements(data.getPowerId(), data.getGrade());
        if (reqs == null) {
            m.sendRaw(player, "status.not-configured");
        } else {
            for (String line : plugin.getEvolution().describe(player, data, reqs)) {
                player.sendMessage(Text.c(line));
            }
            m.sendRaw(player, "status.footer");
        }
    }

    // ------------------------------------------------------------------ /power info

    private void info(Player player, PlayerData data) {
        Messages m = plugin.getMessages();
        Power power = plugin.getPowers().get(data.getPowerId());
        if (!data.hasPower() || power == null) {
            m.send(player, "status.no-power");
            return;
        }
        m.sendRaw(player, "status.header");
        m.sendRaw(player, "info.name", "color", power.getColor(), "symbol", power.getSymbol(), "power", power.getName());
        for (String line : power.cfg().getStringList("description")) {
            player.sendMessage(Text.c(line));
        }
        StringBuilder grades = new StringBuilder();
        for (Grade g : Grade.values()) {
            if (grades.length() > 0) {
                grades.append(" &8› ");
            }
            if (g == data.getGrade()) {
                grades.append("&e&l[").append(g.name()).append("]&r");
            } else if (g.ordinal() < data.getGrade().ordinal()) {
                grades.append("&a").append(g.name());
            } else {
                grades.append("&8").append(g.name());
            }
        }
        m.sendRaw(player, "info.grades", "grades", grades.toString());
        m.sendLines(player, "info.controls");
    }

    // ------------------------------------------------------------------ /power abilities

    private void abilities(Player player, PlayerData data) {
        Messages m = plugin.getMessages();
        Power power = plugin.getPowers().get(data.getPowerId());
        if (!data.hasPower() || power == null) {
            m.send(player, "status.no-power");
            return;
        }
        Ability selected = plugin.getPowers().selected(data);
        m.sendRaw(player, "status.header");
        for (Ability a : power.getAbilities()) {
            boolean unlocked = data.getGrade().isAtLeast(a.getUnlockGrade());
            String grade = plugin.gradeLabel(a.getUnlockGrade());
            if (unlocked) {
                m.sendRaw(player, "abilities.unlocked",
                        "marker", a == selected ? "&e▶" : " ",
                        "color", power.getColor(), "name", a.getName(), "grade", grade,
                        "cooldown", Text.duration(a.getCooldownMillis()));
                if (!a.getDescription().isEmpty()) {
                    m.sendRaw(player, "abilities.description", "description", a.getDescription());
                }
            } else {
                m.sendRaw(player, "abilities.locked", "name", a.getName(), "grade", grade);
            }
        }
    }

    // ------------------------------------------------------------------ /power evolve

    private void evolve(Player player, PlayerData data) {
        Messages m = plugin.getMessages();
        EvolutionManager.Result result = plugin.getEvolution().evolve(player, data);
        switch (result) {
            case NO_POWER -> m.send(player, "status.no-power");
            case MAX_GRADE -> m.send(player, "evolve.max");
            case NOT_CONFIGURED -> m.send(player, "evolve.not-configured");
            case BUSY -> m.send(player, "evolve.busy");
            case MISSING -> {
                m.send(player, "evolve.missing");
                List<EvolutionManager.Requirement> reqs = plugin.getEvolution().getRequirements(data.getPowerId(), data.getGrade());
                if (reqs != null) {
                    for (String line : plugin.getEvolution().describe(player, data, reqs)) {
                        player.sendMessage(Text.c(line));
                    }
                }
            }
            case SUCCESS -> {
                String grade = plugin.gradeLabel(data.getGrade());
                m.send(player, "evolve.success", "grade", grade);
                player.showTitle(Title.title(Text.c(m.raw("evolve.title", "grade", grade)),
                        Text.c(m.raw("evolve.subtitle"))));
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                Grade from = Grade.parse(plugin.getConfig().getString("evolution.broadcast-from-grade", "S"));
                if (from != null && data.getGrade().isAtLeast(from)) {
                    Bukkit.broadcast(Text.c(m.raw("prefix") + m.raw("evolve.broadcast",
                            "player", player.getName(), "grade", grade,
                            "power", plugin.getPowers().color(data.getPowerId()) + plugin.getPowers().name(data.getPowerId()))));
                }
            }
        }
    }

    // ------------------------------------------------------------------ /power select

    private void select(Player player, PlayerData data, String[] args) {
        Messages m = plugin.getMessages();
        if (!data.hasPower()) {
            m.send(player, "status.no-power");
            return;
        }
        if (args.length < 2) {
            plugin.getPowers().cycle(player, 1);
            return;
        }
        if (!plugin.getPowers().select(player, data, args[1])) {
            m.send(player, "select.unknown", "ability", args[1]);
        }
    }

    // ------------------------------------------------------------------ tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("help", "info", "abilities", "choose", "switch", "evolve", "select", "trial"), args[0]);
        }
        if (args.length == 2 && sender instanceof Player p) {
            if (args[0].equalsIgnoreCase("select")) {
                PlayerData data = plugin.getDataManager().get(p);
                List<String> ids = new ArrayList<>();
                if (data != null) {
                    for (Ability a : plugin.getPowers().unlocked(data)) {
                        ids.add(a.getId());
                    }
                }
                return filter(ids, args[1]);
            }
            if (args[0].equalsIgnoreCase("trial")) {
                return filter(new ArrayList<>(plugin.getTrials().ids()), args[1]);
            }
        }
        return List.of();
    }

    static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
            }
        }
        return out;
    }
}
