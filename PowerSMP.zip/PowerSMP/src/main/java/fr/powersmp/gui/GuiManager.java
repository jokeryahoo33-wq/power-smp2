package fr.powersmp.gui;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Grade;
import fr.powersmp.power.Power;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Interfaces : liste des 10 pouvoirs -> confirmation. Deux modes :
 * CHOOSE (premier choix, gratuit) et SWITCH (changement payant à prix fixe).
 * Les positions, matériaux et textes sont dans config.yml (section gui) et messages.yml.
 */
public final class GuiManager {

    public enum Type { SELECT, CONFIRM }

    public enum Mode { CHOOSE, SWITCH }

    /** Identifie nos inventaires (et porte leur état). */
    public static final class Holder implements InventoryHolder {
        private final Type type;
        private final Mode mode;
        private final String powerId;
        private final String currentAtOpen;
        private final Map<Integer, String> powerSlots = new HashMap<>();
        private Inventory inventory;

        Holder(Type type, Mode mode, String powerId, String currentAtOpen) {
            this.type = type;
            this.mode = mode;
            this.powerId = powerId;
            this.currentAtOpen = currentAtOpen;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final PowerSMP plugin;

    public GuiManager(PowerSMP plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ construction

    private Material material(String name, Material fallback) {
        Material m = name == null ? null : Material.matchMaterial(name);
        return m == null || m.isAir() ? fallback : m;
    }

    private ItemStack icon(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.item(name));
        meta.lore(Text.itemLines(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private void fill(Inventory inv) {
        ItemStack filler = icon(material(plugin.getConfig().getString("gui.filler"), Material.BLACK_STAINED_GLASS_PANE), " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, filler);
        }
    }

    private String priceText() {
        double price = plugin.getConfig().getDouble("switch.price", 10_000_000);
        return plugin.getEconomy().format(price);
    }

    private ItemStack powerIcon(String id, PlayerData data, Mode mode, boolean confirmView) {
        FileConfiguration c = plugin.getConfig();
        Messages m = plugin.getMessages();
        Material mat = material(c.getString("powers." + id + ".icon"), Material.PAPER);
        String color = plugin.getPowers().color(id);
        String name = color + plugin.getPowers().symbol(id) + " " + plugin.getPowers().name(id);
        List<String> lore = new ArrayList<>(c.getStringList("powers." + id + ".description"));
        lore.add("");
        if (id.equals(data.getPowerId())) {
            lore.add(m.raw("gui.status.current"));
        } else if (!plugin.getPowers().isSelectable(id)) {
            lore.add(m.raw("gui.status.locked"));
        } else if (!confirmView) {
            lore.add(m.raw(mode == Mode.SWITCH ? "gui.status.click-switch" : "gui.status.click-choose"));
        }
        if (mode == Mode.SWITCH && confirmView) {
            lore.add(m.raw("gui.confirm.price", "price", priceText()));
        }
        return icon(mat, name, lore);
    }

    public void openSelect(Player player, Mode mode) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            return;
        }
        FileConfiguration c = plugin.getConfig();
        Messages m = plugin.getMessages();
        int size = Math.max(27, Math.min(54, c.getInt("gui.select.size", 36) / 9 * 9));
        Holder holder = new Holder(Type.SELECT, mode, null, data.getPowerId());
        String title = mode == Mode.SWITCH ? m.raw("gui.select.title-switch") : m.raw("gui.select.title-choose");
        Inventory inv = Bukkit.createInventory(holder, size, Text.c(title));
        holder.inventory = inv;
        fill(inv);

        for (String id : plugin.getPowers().configuredIds()) {
            int slot = c.getInt("powers." + id + ".slot", -1);
            if (slot < 0 || slot >= size) {
                continue;
            }
            inv.setItem(slot, powerIcon(id, data, mode, false));
            holder.powerSlots.put(slot, id);
        }

        // Carte d'information : pouvoir actuel, grade, prix du switch.
        int infoSlot = c.getInt("gui.select.info-slot", 31);
        if (infoSlot >= 0 && infoSlot < size) {
            List<String> lore = new ArrayList<>();
            if (data.hasPower()) {
                lore.add(m.raw("gui.info.power", "power", plugin.getPowers().color(data.getPowerId())
                        + plugin.getPowers().name(data.getPowerId())));
                lore.add(m.raw("gui.info.grade", "grade", plugin.gradeLabel(data.getGrade())));
            } else {
                lore.add(m.raw("gui.info.no-power"));
            }
            if (mode == Mode.SWITCH) {
                lore.add("");
                lore.add(m.raw("gui.info.price", "price", priceText()));
                lore.add(m.raw("gui.info.warning"));
            }
            inv.setItem(infoSlot, icon(material(c.getString("gui.select.info-material"), Material.BOOK),
                    m.raw("gui.info.name"), lore));
        }
        int closeSlot = c.getInt("gui.select.close-slot", 35);
        if (closeSlot >= 0 && closeSlot < size) {
            inv.setItem(closeSlot, icon(Material.BARRIER, m.raw("gui.close"), List.of()));
        }
        player.openInventory(inv);
    }

    public void openConfirm(Player player, Mode mode, String powerId) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            return;
        }
        FileConfiguration c = plugin.getConfig();
        Messages m = plugin.getMessages();
        Holder holder = new Holder(Type.CONFIRM, mode, powerId, data.getPowerId());
        Inventory inv = Bukkit.createInventory(holder, 27, Text.c(m.raw("gui.confirm.title")));
        holder.inventory = inv;
        fill(inv);

        List<String> confirmLore = new ArrayList<>();
        confirmLore.add(m.raw("gui.confirm.confirm-lore", "power", plugin.getPowers().color(powerId) + plugin.getPowers().name(powerId)));
        if (mode == Mode.SWITCH) {
            confirmLore.add(m.raw("gui.confirm.price", "price", priceText()));
            confirmLore.add(m.raw("gui.confirm.loss"));
        }
        inv.setItem(c.getInt("gui.confirm.confirm-slot", 11),
                icon(material(c.getString("gui.confirm.confirm-material"), Material.LIME_CONCRETE),
                        m.raw("gui.confirm.confirm"), confirmLore));
        inv.setItem(c.getInt("gui.confirm.power-slot", 13), powerIcon(powerId, data, mode, true));
        inv.setItem(c.getInt("gui.confirm.back-slot", 15),
                icon(material(c.getString("gui.confirm.back-material"), Material.RED_CONCRETE),
                        m.raw("gui.confirm.back"), List.of(m.raw("gui.confirm.back-lore"))));
        player.openInventory(inv);
    }

    // ------------------------------------------------------------------ clics

    /** Appelé par GuiListener pour chaque clic dans le haut de nos inventaires. */
    public void handleClick(Player player, Holder holder, int slot) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            return;
        }
        FileConfiguration c = plugin.getConfig();
        Messages m = plugin.getMessages();

        if (holder.type == Type.SELECT) {
            if (slot == c.getInt("gui.select.close-slot", 35)) {
                later(player::closeInventory);
                return;
            }
            String powerId = holder.powerSlots.get(slot);
            if (powerId == null) {
                return;
            }
            if (!plugin.getPowers().isSelectable(powerId)) {
                m.send(player, "gui.not-available", "power", plugin.getPowers().name(powerId));
                return;
            }
            if (holder.mode == Mode.SWITCH && powerId.equals(data.getPowerId())) {
                m.send(player, "switch.same-power");
                return;
            }
            later(() -> openConfirm(player, holder.mode, powerId));
            return;
        }

        // CONFIRM
        if (slot == c.getInt("gui.confirm.confirm-slot", 11)) {
            later(() -> {
                confirm(player, holder);
                player.closeInventory();
            });
        } else if (slot == c.getInt("gui.confirm.back-slot", 15)) {
            later(() -> openSelect(player, holder.mode));
        }
    }

    private void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    // ------------------------------------------------------------------ validation du choix / switch

    private void confirm(Player player, Holder holder) {
        PlayerData data = plugin.getDataManager().get(player);
        Messages m = plugin.getMessages();
        if (data == null || data.isBusy()) {
            return;
        }
        String powerId = holder.powerId;
        if (!plugin.getPowers().isSelectable(powerId)) {
            m.send(player, "gui.not-available", "power", plugin.getPowers().name(powerId));
            return;
        }
        data.setBusy(true);
        try {
            if (holder.mode == Mode.CHOOSE) {
                if (!player.hasPermission("powersmp.choose")) {
                    m.send(player, "no-permission");
                    return;
                }
                if (data.hasPower()) {
                    m.send(player, "choose.already");
                    return;
                }
                plugin.getPowers().assign(data, powerId);
                announce(player, powerId, "choose.done");
            } else {
                doSwitch(player, data, holder, powerId);
            }
        } finally {
            data.setBusy(false);
        }
    }

    private void doSwitch(Player player, PlayerData data, Holder holder, String newPowerId) {
        Messages m = plugin.getMessages();
        if (!player.hasPermission("powersmp.switch")) {
            m.send(player, "no-permission");
            return;
        }
        if (!data.hasPower()) {
            m.send(player, "switch.no-power");
            return;
        }
        // L'état a changé depuis l'ouverture du menu : on refuse (anti-exploit).
        if (!data.getPowerId().equals(holder.currentAtOpen)) {
            m.send(player, "switch.stale");
            return;
        }
        if (newPowerId.equals(data.getPowerId())) {
            m.send(player, "switch.same-power");
            return;
        }
        double price = plugin.getConfig().getDouble("switch.price", 10_000_000);
        if (!plugin.getEconomy().isReady()) {
            m.send(player, "switch.no-economy");
            return;
        }
        if (!plugin.getEconomy().has(player, price)) {
            m.send(player, "switch.not-enough", "price", plugin.getEconomy().format(price));
            return;
        }
        if (!plugin.getEconomy().withdraw(player, price)) {
            m.send(player, "switch.payment-failed");
            return;
        }
        String oldPowerId = data.getPowerId();
        Grade oldGrade = data.getGrade();
        try {
            plugin.getPowers().assign(data, newPowerId);
        } catch (RuntimeException e) {
            plugin.getEconomy().deposit(player, price);
            plugin.getLogger().log(Level.SEVERE, "Switch échoué, remboursement de " + player.getName(), e);
            m.send(player, "switch.error");
            return;
        }
        plugin.getLogger().info(player.getName() + " a changé de pouvoir : " + oldPowerId + " (" + oldGrade + ") -> "
                + newPowerId + " pour " + price);
        announce(player, newPowerId, "switch.done");
    }

    private void announce(Player player, String powerId, String messageKey) {
        Messages m = plugin.getMessages();
        Power power = plugin.getPowers().get(powerId);
        String display = plugin.getPowers().color(powerId) + plugin.getPowers().symbol(powerId) + " "
                + plugin.getPowers().name(powerId);
        m.send(player, messageKey, "power", display);
        player.showTitle(Title.title(Text.c(display), Text.c(m.raw("choose.subtitle"))));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        if (power != null) {
            plugin.getPowers().showSelected(player, plugin.getDataManager().get(player));
        }
    }
}
