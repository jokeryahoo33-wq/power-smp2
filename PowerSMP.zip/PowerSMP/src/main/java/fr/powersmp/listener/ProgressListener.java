package fr.powersmp.listener;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.projectiles.ProjectileSource;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** Progression : boss, monstres d'épreuve, compteurs de kills, objets spéciaux lâchés par les monstres. */
public final class ProgressListener implements Listener {

    private final PowerSMP plugin;

    public ProgressListener(PowerSMP plugin) {
        this.plugin = plugin;
    }

    /** Suivi des dégâts infligés aux boss (le joueur peut tirer à l'arc ou utiliser une capacité). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof LivingEntity victim)) {
            return;
        }
        Player damager = null;
        if (event.getDamager() instanceof Player p) {
            damager = p;
        } else if (event.getDamager() instanceof Projectile proj) {
            ProjectileSource shooter = proj.getShooter();
            if (shooter instanceof Player p) {
                damager = p;
            }
        }
        if (damager != null) {
            plugin.getBosses().recordDamage(victim, damager, event.getFinalDamage());
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        LivingEntity victim = event.getEntity();

        // Monstres d'épreuve : jamais de butin ni d'XP.
        if (plugin.getTrials().isTrialMob(victim)) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            return;
        }
        // Boss : crédit + butin.
        if (plugin.getBosses().handleDeath(event)) {
            return;
        }
        if (victim instanceof Player) {
            return;
        }
        Player killer = victim.getKiller();
        if (killer == null) {
            return;
        }
        PlayerData data = plugin.getDataManager().get(killer);
        if (data == null || !data.hasPower()) {
            return;
        }
        // Anti-farm : les monstres de spawner ne comptent pas (configurable).
        if (plugin.getConfig().getBoolean("anti-farm.ignore-spawner-mobs", true)
                && victim.getEntitySpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER) {
            return;
        }
        plugin.getEvolution().onKill(killer, data, victim);

        // Objets spéciaux lâchés par certains monstres.
        String type = victim.getType().name();
        for (Map<?, ?> source : plugin.getConfig().getMapList("item-sources")) {
            Object entity = source.get("entity");
            Object item = source.get("item");
            if (entity == null || item == null || !type.equalsIgnoreCase(String.valueOf(entity))) {
                continue;
            }
            String itemId = String.valueOf(item).toLowerCase(Locale.ROOT);
            if (!plugin.getItems().exists(itemId)) {
                continue;
            }
            Object chanceObj = source.get("chance");
            double chance = chanceObj instanceof Number n ? n.doubleValue() : 0.0;
            Object amountObj = source.get("amount");
            int amount = amountObj instanceof Number n ? Math.max(1, n.intValue()) : 1;
            if (ThreadLocalRandom.current().nextDouble() < chance) {
                plugin.getItems().give(killer, itemId, amount);
                plugin.getMessages().actionBar(killer, "loot.found",
                        "item", plugin.getItems().getName(itemId), "amount", String.valueOf(amount));
            }
        }
    }
}
