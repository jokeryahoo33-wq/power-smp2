package fr.powersmp.listener;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

/**
 * Contrôles des capacités :
 *  - Sneak + touche F (échange de main)  -> lance la capacité sélectionnée
 *  - Sneak + molette de la souris        -> change de capacité
 */
public final class AbilityListener implements Listener {

    private final PowerSMP plugin;

    public AbilityListener(PowerSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (!player.isSneaking() || !plugin.getConfig().getBoolean("controls.sneak-swap-cast", true)) {
            return;
        }
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null || !data.hasPower()) {
            return;
        }
        event.setCancelled(true);
        plugin.getPowers().cast(player);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onScroll(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (!player.isSneaking() || !plugin.getConfig().getBoolean("controls.sneak-scroll-select", true)) {
            return;
        }
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null || !data.hasPower()) {
            return;
        }
        // Avec une seule capacité, on laisse la molette fonctionner normalement.
        if (plugin.getPowers().unlocked(data).size() < 2) {
            return;
        }
        int delta = ((event.getNewSlot() - event.getPreviousSlot()) % 9 + 9) % 9;
        int dir = (delta >= 1 && delta <= 4) ? 1 : -1;
        event.setCancelled(true);
        plugin.getPowers().cycle(player, dir);
    }
}
