package fr.powersmp.listener;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.gui.GuiManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Connexion / déconnexion / mort. */
public final class PlayerListener implements Listener {

    private final PowerSMP plugin;

    public PlayerListener(PowerSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().load(player);
        if (data == null || data.hasPower()) {
            return;
        }
        if (!plugin.getConfig().getBoolean("choose.open-gui-on-join", true)
                || !player.hasPermission("powersmp.choose")) {
            return;
        }
        long delay = plugin.getConfig().getLong("choose.open-gui-delay-ticks", 40);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            PlayerData current = plugin.getDataManager().get(player);
            if (player.isOnline() && current != null && !current.hasPower()) {
                plugin.getGui().openSelect(player, GuiManager.Mode.CHOOSE);
                plugin.getMessages().send(player, "choose.reminder");
            }
        }, delay);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getTrials().cancel(player.getUniqueId(), null);
        plugin.getDataManager().unload(player);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        plugin.getTrials().cancel(event.getEntity().getUniqueId(), "trial.failed-death");
    }
}
