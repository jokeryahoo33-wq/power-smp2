package fr.powersmp.listener;

import fr.powersmp.PowerSMP;
import fr.powersmp.gui.GuiManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Rend nos menus intouchables (aucun objet ne peut être pris, déplacé ou glissé) et route les clics. */
public final class GuiListener implements Listener {

    private final PowerSMP plugin;

    public GuiListener(PowerSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof GuiManager.Holder holder)) {
            return;
        }
        // Annule TOUT clic (y compris shift-clic depuis l'inventaire du joueur).
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null
                || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }
        plugin.getGui().handleClick(player, holder, event.getRawSlot());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GuiManager.Holder) {
            event.setCancelled(true);
        }
    }
}
