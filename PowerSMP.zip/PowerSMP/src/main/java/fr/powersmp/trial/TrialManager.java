package fr.powersmp.trial;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.evolution.EvolutionManager;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * Épreuves (section "trials:" de config.yml) : le joueur se place dans un Sanctuaire (posé par un admin avec
 * /powersmp sanctuary set) et lance /power trial &lt;id&gt; ; il doit survivre à des vagues de monstres pendant X secondes
 * sans quitter la zone. Les monstres d'épreuve ne lâchent ni butin ni XP (pas de farm).
 */
public final class TrialManager {

    private final PowerSMP plugin;
    private final NamespacedKey mobKey;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final File storeFile;
    private final YamlConfiguration store;

    public TrialManager(PowerSMP plugin) {
        this.plugin = plugin;
        this.mobKey = new NamespacedKey(plugin, "trial_mob");
        this.storeFile = new File(plugin.getDataFolder(), "sanctuaries.yml");
        this.store = YamlConfiguration.loadConfiguration(storeFile);
    }

    private ConfigurationSection cfg(String id) {
        return plugin.getConfig().getConfigurationSection("trials." + id);
    }

    public boolean exists(String id) {
        return cfg(id) != null;
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("trials");
        return s == null ? Set.of() : s.getKeys(false);
    }

    /** Nom brut (avec codes &). */
    public String getName(String id) {
        ConfigurationSection s = cfg(id);
        return s == null ? id : s.getString("name", id);
    }

    public boolean isTrialMob(Entity entity) {
        return entity.getPersistentDataContainer().has(mobKey, PersistentDataType.STRING);
    }

    public boolean isInTrial(UUID uuid) {
        return sessions.containsKey(uuid);
    }

    // ------------------------------------------------------------------ sanctuaires

    public void setSanctuary(String id, Location loc) {
        store.set(id + ".world", loc.getWorld().getName());
        store.set(id + ".x", loc.getX());
        store.set(id + ".y", loc.getY());
        store.set(id + ".z", loc.getZ());
        try {
            store.save(storeFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Impossible d'écrire sanctuaries.yml", e);
        }
    }

    public Location getSanctuary(String id) {
        String worldName = store.getString(id + ".world");
        if (worldName == null) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world, store.getDouble(id + ".x"), store.getDouble(id + ".y"), store.getDouble(id + ".z"));
    }

    // ------------------------------------------------------------------ déroulement

    public void start(Player player, PlayerData data, String id) {
        Messages m = plugin.getMessages();
        if (sessions.containsKey(player.getUniqueId())) {
            m.send(player, "trial.already");
            return;
        }
        if (!exists(id)) {
            m.send(player, "trial.unknown", "id", id);
            return;
        }
        if (!data.hasPower()) {
            m.send(player, "status.no-power");
            return;
        }
        // L'épreuve doit servir au prochain grade et ne pas déjà être réussie.
        List<EvolutionManager.Requirement> reqs = plugin.getEvolution().getRequirements(data.getPowerId(), data.getGrade());
        boolean needed = false;
        if (reqs != null) {
            for (EvolutionManager.Requirement r : reqs) {
                if (r.type() == EvolutionManager.Type.TRIAL && r.id().equals(id)
                        && data.getProgress("trial:" + id) < r.amount()) {
                    needed = true;
                    break;
                }
            }
        }
        if (!needed) {
            m.send(player, "trial.not-needed", "trial", getName(id));
            return;
        }
        Location sanctuary = getSanctuary(id);
        if (sanctuary == null) {
            m.send(player, "trial.no-sanctuary");
            return;
        }
        ConfigurationSection c = cfg(id);
        double radius = c.getDouble("radius", 20);
        if (!player.getWorld().equals(sanctuary.getWorld()) || player.getLocation().distance(sanctuary) > radius) {
            m.send(player, "trial.too-far", "radius", String.valueOf((int) radius));
            return;
        }
        Session session = new Session(player.getUniqueId(), id, sanctuary, radius,
                Math.max(5, c.getInt("duration-seconds", 60)),
                Math.max(1, c.getInt("wave-interval-seconds", 10)),
                data.getEpoch());
        sessions.put(player.getUniqueId(), session);
        session.runTaskTimer(plugin, 20L, 20L);
        m.send(player, "trial.started", "trial", getName(id), "seconds", String.valueOf(session.duration));
    }

    /** Annule l'épreuve d'un joueur (mort, déconnexion, changement de pouvoir...). */
    public void cancel(UUID uuid, String failKey) {
        Session s = sessions.get(uuid);
        if (s != null) {
            s.finish(false, failKey);
        }
    }

    public void shutdown() {
        for (Session s : new ArrayList<>(sessions.values())) {
            s.finish(false, null);
        }
        sessions.clear();
    }

    private final class Session extends BukkitRunnable {
        private final UUID uuid;
        private final String trialId;
        private final Location center;
        private final double radius;
        private final int duration;
        private final int waveInterval;
        private final int epoch;
        private final List<UUID> mobs = new ArrayList<>();
        private int elapsed = 0;
        private boolean finished = false;

        Session(UUID uuid, String trialId, Location center, double radius, int duration, int waveInterval, int epoch) {
            this.uuid = uuid;
            this.trialId = trialId;
            this.center = center;
            this.radius = radius;
            this.duration = duration;
            this.waveInterval = waveInterval;
            this.epoch = epoch;
        }

        @Override
        public void run() {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) {
                finish(false, null);
                return;
            }
            PlayerData data = plugin.getDataManager().get(p);
            if (data == null || data.getEpoch() != epoch) {
                finish(false, "trial.failed-changed");
                return;
            }
            if (p.isDead()) {
                finish(false, "trial.failed-death");
                return;
            }
            if (!p.getWorld().equals(center.getWorld()) || p.getLocation().distance(center) > radius) {
                finish(false, "trial.failed-left");
                return;
            }
            elapsed++;
            if (elapsed == 1 || elapsed % waveInterval == 0) {
                spawnWave(p);
            }
            plugin.getMessages().actionBar(p, "trial.remaining", "seconds", String.valueOf(duration - elapsed));
            if (elapsed >= duration) {
                finish(true, null);
            }
        }

        void finish(boolean success, String failKey) {
            if (finished) {
                return;
            }
            finished = true;
            cancel();
            sessions.remove(uuid);
            for (UUID mobId : mobs) {
                Entity e = Bukkit.getEntity(mobId);
                if (e != null) {
                    e.remove();
                }
            }
            mobs.clear();

            Player p = Bukkit.getPlayer(uuid);
            if (p == null) {
                return;
            }
            if (success) {
                PlayerData data = plugin.getDataManager().get(p);
                if (data != null) {
                    data.addProgress("trial:" + trialId, 1);
                    plugin.getDataManager().saveAsync(data);
                }
                plugin.getMessages().send(p, "trial.success", "trial", getName(trialId));
            } else if (failKey != null) {
                plugin.getMessages().send(p, failKey);
            }
        }

        private void spawnWave(Player p) {
            ConfigurationSection c = cfg(trialId);
            if (c == null) {
                return;
            }
            List<String> types = c.getStringList("mobs");
            if (types.isEmpty()) {
                return;
            }
            int count = Math.max(1, Math.min(c.getInt("mobs-per-wave", 3), 12));
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            for (int i = 0; i < count; i++) {
                EntityType type;
                try {
                    type = EntityType.valueOf(types.get(rnd.nextInt(types.size())).toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException e) {
                    continue;
                }
                Entity entity = p.getWorld().spawnEntity(findSpawn(p), type);
                entity.getPersistentDataContainer().set(mobKey, PersistentDataType.STRING, uuid.toString());
                if (entity instanceof Mob mob) {
                    mob.setTarget(p);
                }
                mobs.add(entity.getUniqueId());
            }
        }

        private Location findSpawn(Player p) {
            ThreadLocalRandom rnd = ThreadLocalRandom.current();
            Location base = p.getLocation();
            for (int attempt = 0; attempt < 10; attempt++) {
                double angle = rnd.nextDouble() * Math.PI * 2;
                double dist = 6 + rnd.nextDouble() * 6;
                Location l = base.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
                Block feet = l.getBlock();
                Block head = feet.getRelative(BlockFace.UP);
                Block ground = feet.getRelative(BlockFace.DOWN);
                if (feet.isPassable() && head.isPassable() && !ground.isPassable()) {
                    return feet.getLocation().add(0.5, 0, 0.5);
                }
            }
            return base;
        }
    }
}
