package fr.powersmp.item;

import fr.powersmp.PowerSMP;
import fr.powersmp.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Map;
import java.util.Set;

/**
 * Objets spéciaux (Éclat de Foudre, Noyau de Foudre...) définis dans config.yml sous "items:".
 * Ils sont reconnus par une donnée cachée (PDC) : renommer un objet normal ne permet pas de le falsifier.
 */
public final class CustomItems {

    private final PowerSMP plugin;
    private final NamespacedKey key;

    public CustomItems(PowerSMP plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "item_id");
    }

    private ConfigurationSection cfg(String id) {
        return plugin.getConfig().getConfigurationSection("items." + id);
    }

    public boolean exists(String id) {
        return cfg(id) != null;
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items");
        return s == null ? Set.of() : s.getKeys(false);
    }

    /** Nom brut (avec codes &) ; l'id si l'objet n'existe pas. */
    public String getName(String id) {
        ConfigurationSection s = cfg(id);
        return s == null ? id : s.getString("name", id);
    }

    public ItemStack create(String id, int amount) {
        ConfigurationSection s = cfg(id);
        if (s == null) {
            return null;
        }
        Material material = Material.matchMaterial(s.getString("material", "PAPER"));
        if (material == null || material.isAir()) {
            material = Material.PAPER;
        }
        ItemStack stack = new ItemStack(material, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.item(s.getString("name", id)));
        meta.lore(Text.itemLines(s.getStringList("lore")));
        if (s.getBoolean("glow", true)) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Id de l'objet spécial, ou null si c'est un objet ordinaire. */
    public String getId(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    /** Donne l'objet ; ce qui ne rentre pas tombe au sol, réservé au joueur. */
    public void give(Player player, String id, int amount) {
        int remaining = Math.max(1, amount);
        while (remaining > 0) {
            ItemStack probe = create(id, 1);
            if (probe == null) {
                return;
            }
            int n = Math.min(remaining, probe.getMaxStackSize());
            ItemStack stack = create(id, n);
            Map<Integer, ItemStack> left = player.getInventory().addItem(stack);
            for (ItemStack extra : left.values()) {
                Item dropped = player.getWorld().dropItemNaturally(player.getLocation(), extra);
                dropped.setOwner(player.getUniqueId());
            }
            remaining -= n;
        }
    }

    // ---------------------------------------------------------------- comptage / retrait

    public int count(Player player, String id) {
        PlayerInventory inv = player.getInventory();
        int total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s != null && id.equals(getId(s))) {
                total += s.getAmount();
            }
        }
        return total;
    }

    /** Retire exactement amount objets spéciaux. Retourne false (sans rien retirer) s'il n'y en a pas assez. */
    public boolean remove(Player player, String id, int amount) {
        if (count(player, id) < amount) {
            return false;
        }
        PlayerInventory inv = player.getInventory();
        int left = amount;
        for (int i = 0; i < 36 && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || !id.equals(getId(s))) {
                continue;
            }
            int take = Math.min(left, s.getAmount());
            if (take >= s.getAmount()) {
                inv.setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - take);
                inv.setItem(i, s);
            }
            left -= take;
        }
        return true;
    }

    /** Objets "ordinaires" : sans données cachées ni nom/lore/enchantements personnalisés. */
    private boolean isPlain(ItemStack s, Material material) {
        return s != null && s.getType() == material && !s.hasItemMeta();
    }

    public int countMaterial(Player player, Material material) {
        PlayerInventory inv = player.getInventory();
        int total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (isPlain(s, material)) {
                total += s.getAmount();
            }
        }
        return total;
    }

    public boolean removeMaterial(Player player, Material material, int amount) {
        if (countMaterial(player, material) < amount) {
            return false;
        }
        PlayerInventory inv = player.getInventory();
        int left = amount;
        for (int i = 0; i < 36 && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!isPlain(s, material)) {
                continue;
            }
            int take = Math.min(left, s.getAmount());
            if (take >= s.getAmount()) {
                inv.setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - take);
                inv.setItem(i, s);
            }
            left -= take;
        }
        return true;
    }
}
