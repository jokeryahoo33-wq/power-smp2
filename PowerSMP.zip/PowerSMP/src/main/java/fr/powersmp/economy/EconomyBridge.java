package fr.powersmp.economy;

import fr.powersmp.PowerSMP;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Pont vers l'économie EXISTANTE du serveur via Vault (EssentialsX, EconomyShopGUI... partagent la même).
 * Le plugin ne crée aucune économie à lui.
 */
public final class EconomyBridge {

    private final PowerSMP plugin;
    private Economy economy;

    public EconomyBridge(PowerSMP plugin) {
        this.plugin = plugin;
    }

    /** Récupère le fournisseur d'économie au moment de l'usage (il peut s'enregistrer après notre démarrage). */
    private Economy eco() {
        if (economy != null) {
            return economy;
        }
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return null;
        }
        try {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                economy = rsp.getProvider();
            }
        } catch (Throwable t) {
            plugin.getLogger().warning("Vault est présent mais l'économie est inaccessible : " + t.getMessage());
        }
        return economy;
    }

    public boolean isReady() {
        return eco() != null;
    }

    public boolean has(Player player, double amount) {
        Economy e = eco();
        return e != null && e.has(player, amount);
    }

    /** Retire l'argent. Retourne true seulement si la transaction a réussi. */
    public boolean withdraw(Player player, double amount) {
        Economy e = eco();
        if (e == null) {
            return false;
        }
        EconomyResponse r = e.withdrawPlayer(player, amount);
        return r != null && r.transactionSuccess();
    }

    /** Rembourse (utilisé si une erreur survient après le prélèvement). */
    public void deposit(Player player, double amount) {
        Economy e = eco();
        if (e != null) {
            e.depositPlayer(player, amount);
        }
    }

    public String format(double amount) {
        Economy e = eco();
        if (e != null) {
            try {
                return e.format(amount);
            } catch (Throwable ignored) {
                // on retombe sur le format simple
            }
        }
        return NumberFormat.getIntegerInstance(Locale.FRANCE).format(amount) + " $";
    }
}
