package fr.powersmp.evolution;

import fr.powersmp.PowerSMP;
import fr.powersmp.data.PlayerData;
import fr.powersmp.power.Grade;
import fr.powersmp.util.Messages;
import fr.powersmp.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Évolution des grades. Les conditions de chaque grade sont dans config.yml
 * (powers.&lt;pouvoir&gt;.evolution.&lt;grade&gt;). AUCUN type de condition ne fait intervenir l'argent.
 */
public final class EvolutionManager {

    public enum Type { ITEM, MATERIAL, BOSS, TRIAL, KILLS }

    public record Requirement(Type type, String id, int amount, String label) {
    }

    public enum Result { SUCCESS, NO_POWER, MAX_GRADE, NOT_CONFIGURED, MISSING, BUSY }

    private final PowerSMP plugin;

    public EvolutionManager(PowerSMP plugin) {
        this.plugin = plugin;
    }

    /**
     * Conditions pour quitter le grade donné. Retourne null si rien n'est configuré ou si la config est invalide :
     * dans ce cas l'évolution est REFUSÉE (jamais gratuite par erreur de config).
     */
    public List<Requirement> getRequirements(String powerId, Grade grade) {
        List<Map<?, ?>> raw = plugin.getConfig().getMapList("powers." + powerId + ".evolution." + grade.name());
        if (raw.isEmpty()) {
            return null;
        }
        List<Requirement> list = new ArrayList<>();
        for (Map<?, ?> m : raw) {
            Object t = m.get("type");
            Object id = m.get("id");
            if (t == null || id == null) {
                plugin.getLogger().warning("Condition invalide (type/id manquant) pour " + powerId + " grade " + grade);
                return null;
            }
            Type type;
            try {
                type = Type.valueOf(String.valueOf(t).toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Type de condition inconnu '" + t + "' pour " + powerId + " grade " + grade);
                return null;
            }
            Object a = m.get("amount");
            int amount = a instanceof Number n ? Math.max(1, n.intValue()) : 1;
            Object l = m.get("label");
            list.add(new Requirement(type, String.valueOf(id), amount, l == null ? null : String.valueOf(l)));
        }
        return list;
    }

    private String progressKey(Requirement r) {
        return switch (r.type()) {
            case BOSS -> "boss:" + r.id();
            case TRIAL -> "trial:" + r.id();
            case KILLS -> "kills:" + r.id().toUpperCase(Locale.ROOT);
            default -> "";
        };
    }

    /** Quantité actuellement possédée / accomplie pour une condition. */
    public int current(Player player, PlayerData data, Requirement r) {
        return switch (r.type()) {
            case ITEM -> plugin.getItems().count(player, r.id());
            case MATERIAL -> {
                Material m = Material.matchMaterial(r.id());
                yield m == null ? 0 : plugin.getItems().countMaterial(player, m);
            }
            case BOSS, TRIAL, KILLS -> data.getProgress(progressKey(r));
        };
    }

    public String label(Requirement r) {
        if (r.label() != null) {
            return r.label();
        }
        return switch (r.type()) {
            case ITEM -> plugin.getItems().getName(r.id());
            case MATERIAL -> "&f" + Text.pretty(r.id());
            case BOSS -> plugin.getBosses().getName(r.id());
            case TRIAL -> plugin.getTrials().getName(r.id());
            case KILLS -> "&f" + Text.pretty(r.id());
        };
    }

    /** Lignes d'affichage "✔ Rassembler Éclat de Foudre (3/3)". */
    public List<String> describe(Player player, PlayerData data, List<Requirement> reqs) {
        Messages m = plugin.getMessages();
        List<String> lines = new ArrayList<>();
        for (Requirement r : reqs) {
            int cur = Math.min(current(player, data, r), r.amount());
            boolean ok = cur >= r.amount();
            String amountPart = r.amount() > 1 && (r.type() == Type.ITEM || r.type() == Type.MATERIAL)
                    ? r.amount() + "x " : "";
            lines.add(m.raw("requirement.line",
                    "status", ok ? m.raw("requirement.ok") : m.raw("requirement.missing"),
                    "verb", m.raw("requirement.verb." + r.type().name().toLowerCase(Locale.ROOT)),
                    "label", amountPart + label(r),
                    "current", String.valueOf(cur),
                    "amount", String.valueOf(r.amount())));
        }
        return lines;
    }

    /** Regroupe les conditions identiques (même type + id) pour éviter les doubles comptages. */
    private List<Requirement> merge(List<Requirement> reqs) {
        Map<String, Requirement> merged = new LinkedHashMap<>();
        for (Requirement r : reqs) {
            String k = r.type() + ":" + r.id().toUpperCase(Locale.ROOT);
            Requirement old = merged.get(k);
            merged.put(k, old == null ? r : new Requirement(r.type(), r.id(), old.amount() + r.amount(), old.label()));
        }
        return new ArrayList<>(merged.values());
    }

    /**
     * Tente de passer au grade suivant : vérifie TOUTES les conditions, puis consomme objets et progression.
     * Tout se fait sur le thread principal en un seul bloc, protégé par un verrou : pas de double récompense.
     */
    public Result evolve(Player player, PlayerData data) {
        if (!data.hasPower() || plugin.getPowers().get(data.getPowerId()) == null) {
            return Result.NO_POWER;
        }
        Grade next = data.getGrade().next();
        if (next == null) {
            return Result.MAX_GRADE;
        }
        if (data.isBusy()) {
            return Result.BUSY;
        }
        List<Requirement> reqs = getRequirements(data.getPowerId(), data.getGrade());
        if (reqs == null) {
            return Result.NOT_CONFIGURED;
        }
        reqs = merge(reqs);

        data.setBusy(true);
        try {
            for (Requirement r : reqs) {
                if (current(player, data, r) < r.amount()) {
                    return Result.MISSING;
                }
            }
            for (Requirement r : reqs) {
                consume(player, data, r);
            }
            data.setGrade(next);
            plugin.getDataManager().saveAsync(data);
            return Result.SUCCESS;
        } finally {
            data.setBusy(false);
        }
    }

    private void consume(Player player, PlayerData data, Requirement r) {
        switch (r.type()) {
            case ITEM -> plugin.getItems().remove(player, r.id(), r.amount());
            case MATERIAL -> {
                Material m = Material.matchMaterial(r.id());
                if (m != null) {
                    plugin.getItems().removeMaterial(player, m, r.amount());
                }
            }
            case BOSS, TRIAL, KILLS -> data.addProgress(progressKey(r), -r.amount());
        }
    }

    /** Appelé quand un joueur tue une entité : compte la mort si une condition KILLS du grade actuel la demande. */
    public void onKill(Player killer, PlayerData data, LivingEntity victim) {
        if (!data.hasPower() || data.getGrade().next() == null) {
            return;
        }
        List<Requirement> reqs = getRequirements(data.getPowerId(), data.getGrade());
        if (reqs == null) {
            return;
        }
        String type = victim.getType().name();
        for (Requirement r : reqs) {
            if (r.type() != Type.KILLS || !r.id().equalsIgnoreCase(type)) {
                continue;
            }
            String key = progressKey(r);
            if (data.getProgress(key) < r.amount()) {
                data.addProgress(key, 1);
                plugin.getMessages().actionBar(killer, "kills.progress",
                        "label", label(r),
                        "current", String.valueOf(data.getProgress(key)),
                        "amount", String.valueOf(r.amount()));
            }
        }
    }
}
