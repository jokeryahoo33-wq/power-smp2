package fr.powersmp.data;

import fr.powersmp.PowerSMP;
import fr.powersmp.power.Grade;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * Stockage SQLite. Toutes les opérations passent par UN SEUL thread : les écritures sont donc
 * exécutées dans l'ordre, et une lecture voit toujours les écritures précédentes.
 * Le driver SQLite est déjà fourni par Paper (rien à embarquer dans le jar).
 */
public final class Database {

    private final PowerSMP plugin;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> new Thread(r, "PowerSMP-DB"));
    private Connection connection;

    public Database(PowerSMP plugin) {
        this.plugin = plugin;
    }

    public void init() throws Exception {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "powersmp.db");
        executor.submit((Callable<Void>) () -> {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=NORMAL");
                st.execute("CREATE TABLE IF NOT EXISTS players ("
                        + "uuid TEXT PRIMARY KEY, name TEXT, power TEXT, grade TEXT NOT NULL, updated INTEGER)");
                st.execute("CREATE TABLE IF NOT EXISTS progress ("
                        + "uuid TEXT NOT NULL, key TEXT NOT NULL, value INTEGER NOT NULL, PRIMARY KEY(uuid, key))");
                st.execute("CREATE TABLE IF NOT EXISTS cooldowns ("
                        + "uuid TEXT NOT NULL, key TEXT NOT NULL, expires INTEGER NOT NULL, PRIMARY KEY(uuid, key))");
            }
            return null;
        }).get(15, TimeUnit.SECONDS);
    }

    /** Lecture (bloquante, mais passe derrière les sauvegardes déjà en file). Null si le joueur est inconnu. */
    public PlayerData load(UUID uuid) throws Exception {
        return executor.submit((Callable<PlayerData>) () -> loadInternal(uuid)).get(10, TimeUnit.SECONDS);
    }

    /** Sauvegarde asynchrone d'un snapshot (utiliser {@link PlayerData#copy()}). */
    public void saveAsync(PlayerData snapshot) {
        try {
            executor.execute(() -> {
                try {
                    saveInternal(snapshot);
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Sauvegarde impossible pour " + snapshot.getName(), e);
                }
            });
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.SEVERE, "File de sauvegarde fermée, données non enregistrées : " + snapshot.getName(), e);
        }
    }

    /** Sauvegarde les derniers snapshots puis ferme proprement la base (appelé à l'arrêt). */
    public void closeAfterSaving(Collection<PlayerData> snapshots) {
        for (PlayerData snap : snapshots) {
            saveAsync(snap);
        }
        try {
            executor.execute(() -> {
                try {
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    plugin.getLogger().log(Level.WARNING, "Fermeture SQLite", e);
                }
            });
        } catch (RuntimeException ignored) {
            // déjà fermé
        }
        executor.shutdown();
        try {
            if (!executor.awaitTermination(20, TimeUnit.SECONDS)) {
                plugin.getLogger().warning("La sauvegarde finale a dépassé 20 secondes.");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ------------------------------------------------------------------ interne (thread DB)

    private PlayerData loadInternal(UUID uuid) throws SQLException {
        String id = uuid.toString();
        PlayerData data;
        try (PreparedStatement ps = connection.prepareStatement("SELECT name, power, grade FROM players WHERE uuid = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                data = new PlayerData(uuid, rs.getString("name"));
                Map<String, Integer> progress = new HashMap<>();
                Map<String, Long> cooldowns = new HashMap<>();
                loadProgress(id, progress);
                loadCooldowns(id, cooldowns);
                data.restore(rs.getString("power"), Grade.parse(rs.getString("grade")), progress, cooldowns);
            }
        }
        return data;
    }

    private void loadProgress(String id, Map<String, Integer> out) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT key, value FROM progress WHERE uuid = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.put(rs.getString("key"), rs.getInt("value"));
                }
            }
        }
    }

    private void loadCooldowns(String id, Map<String, Long> out) throws SQLException {
        long now = System.currentTimeMillis();
        try (PreparedStatement ps = connection.prepareStatement("SELECT key, expires FROM cooldowns WHERE uuid = ?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long expires = rs.getLong("expires");
                    if (expires > now) {
                        out.put(rs.getString("key"), expires);
                    }
                }
            }
        }
    }

    private void saveInternal(PlayerData d) throws SQLException {
        String id = d.getUuid().toString();
        long now = System.currentTimeMillis();
        connection.setAutoCommit(false);
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT OR REPLACE INTO players(uuid, name, power, grade, updated) VALUES(?,?,?,?,?)")) {
                ps.setString(1, id);
                ps.setString(2, d.getName());
                ps.setString(3, d.getPowerId());
                ps.setString(4, d.getGrade().name());
                ps.setLong(5, now);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM progress WHERE uuid = ?")) {
                ps.setString(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO progress(uuid, key, value) VALUES(?,?,?)")) {
                for (Map.Entry<String, Integer> e : d.getProgressMap().entrySet()) {
                    ps.setString(1, id);
                    ps.setString(2, e.getKey());
                    ps.setInt(3, e.getValue());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            try (PreparedStatement ps = connection.prepareStatement("DELETE FROM cooldowns WHERE uuid = ?")) {
                ps.setString(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO cooldowns(uuid, key, expires) VALUES(?,?,?)")) {
                for (Map.Entry<String, Long> e : d.getCooldownMap().entrySet()) {
                    if (e.getValue() > now) {
                        ps.setString(1, id);
                        ps.setString(2, e.getKey());
                        ps.setLong(3, e.getValue());
                        ps.addBatch();
                    }
                }
                ps.executeBatch();
            }
            connection.commit();
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }
}
