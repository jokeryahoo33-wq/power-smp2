package fr.powersmp.data;

import fr.powersmp.PowerSMP;
import fr.powersmp.util.Text;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** Cache mémoire des joueurs connectés + sauvegardes (à chaque changement important, à la sortie, périodiquement). */
public final class PlayerDataManager {

    private final PowerSMP plugin;
    private final Database database;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private BukkitTask autosave;

    public PlayerDataManager(PowerSMP plugin, Database database) {
        this.plugin = plugin;
        this.database = database;
    }

    public PlayerData get(UUID uuid) {
        return cache.get(uuid);
    }

    public PlayerData get(Player player) {
        return cache.get(player.getUniqueId());
    }

    /**
     * Charge les données d'un joueur qui se connecte.
     * Si la lecture échoue, on expulse le joueur plutôt que de risquer d'écraser ses vraies données.
     */
    public PlayerData load(Player player) {
        PlayerData data;
        try {
            data = database.load(player.getUniqueId());
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Lecture impossible pour " + player.getName(), e);
            player.kick(Text.c(plugin.getMessages().raw("database.load-error")));
            return null;
        }
        if (data == null) {
            data = new PlayerData(player.getUniqueId(), player.getName());
        } else {
            data.setName(player.getName());
        }
        cache.put(player.getUniqueId(), data);
        return data;
    }

    /** Sauvegarde asynchrone immédiate (utilisé après un choix, un switch, une évolution...). */
    public void saveAsync(PlayerData data) {
        data.clearDirty();
        database.saveAsync(data.copy());
    }

    public void unload(Player player) {
        PlayerData data = cache.remove(player.getUniqueId());
        if (data != null && data.isDirty()) {
            saveAsync(data);
        }
    }

    public void startAutosave() {
        long ticks = Math.max(1, plugin.getConfig().getLong("database.autosave-minutes", 5)) * 60L * 20L;
        autosave = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (PlayerData d : cache.values()) {
                if (d.isDirty()) {
                    saveAsync(d);
                }
            }
        }, ticks, ticks);
    }

    /** Appelé dans onDisable : sauvegarde tout ce qui est modifié puis ferme la base. */
    public void shutdown() {
        if (autosave != null) {
            autosave.cancel();
        }
        Collection<PlayerData> snapshots = new ArrayList<>();
        List<PlayerData> all = new ArrayList<>(cache.values());
        for (PlayerData d : all) {
            if (d.isDirty()) {
                d.clearDirty();
                snapshots.add(d.copy());
            }
        }
        cache.clear();
        database.closeAfterSaving(snapshots);
    }
}
