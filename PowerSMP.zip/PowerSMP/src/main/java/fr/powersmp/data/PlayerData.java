package fr.powersmp.data;

import fr.powersmp.power.Grade;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Données d'un joueur. Les champs "persistés" sont sauvegardés en SQLite ;
 * les champs "transitoires" n'existent qu'en mémoire.
 */
public final class PlayerData {

    private final UUID uuid;
    private String name;

    // ---- persistés ----
    private String powerId;
    private Grade grade = Grade.F;
    private final Map<String, Integer> progress = new HashMap<>();
    private final Map<String, Long> cooldowns = new HashMap<>();

    // ---- transitoires ----
    private int epoch;
    private String selectedAbility;
    private long lastCastNanos;
    private boolean busy;
    private boolean dirty;

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    /** Charge les valeurs lues en base (ne marque pas "dirty"). */
    void restore(String powerId, Grade grade, Map<String, Integer> progress, Map<String, Long> cooldowns) {
        this.powerId = powerId;
        this.grade = grade == null ? Grade.F : grade;
        this.progress.putAll(progress);
        this.cooldowns.putAll(cooldowns);
    }

    /** Copie des champs persistés, destinée à la sauvegarde asynchrone. */
    public PlayerData copy() {
        PlayerData c = new PlayerData(uuid, name);
        c.powerId = powerId;
        c.grade = grade;
        c.progress.putAll(progress);
        c.cooldowns.putAll(cooldowns);
        return c;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.equals(this.name)) {
            this.name = name;
            dirty = true;
        }
    }

    // ---- pouvoir / grade ----

    public String getPowerId() {
        return powerId;
    }

    public boolean hasPower() {
        return powerId != null;
    }

    public void setPowerId(String powerId) {
        this.powerId = powerId;
        dirty = true;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
        dirty = true;
    }

    // ---- progression ----

    public int getProgress(String key) {
        return progress.getOrDefault(key, 0);
    }

    public void addProgress(String key, int delta) {
        int value = getProgress(key) + delta;
        if (value <= 0) {
            progress.remove(key);
        } else {
            progress.put(key, value);
        }
        dirty = true;
    }

    public void clearProgress() {
        progress.clear();
        dirty = true;
    }

    public Map<String, Integer> getProgressMap() {
        return Collections.unmodifiableMap(progress);
    }

    // ---- cooldowns ----

    public long getCooldownExpiry(String key) {
        return cooldowns.getOrDefault(key, 0L);
    }

    public void setCooldownExpiry(String key, long expiryMillis) {
        cooldowns.put(key, expiryMillis);
        dirty = true;
    }

    public void removeCooldown(String key) {
        if (cooldowns.remove(key) != null) {
            dirty = true;
        }
    }

    public void clearCooldowns() {
        cooldowns.clear();
        dirty = true;
    }

    public Map<String, Long> getCooldownMap() {
        return Collections.unmodifiableMap(cooldowns);
    }

    // ---- transitoires ----

    /** Incrémenté à chaque changement/reset de pouvoir : annule les tâches en cours d'anciennes capacités. */
    public int getEpoch() {
        return epoch;
    }

    public void bumpEpoch() {
        epoch++;
    }

    public String getSelectedAbility() {
        return selectedAbility;
    }

    public void setSelectedAbility(String selectedAbility) {
        this.selectedAbility = selectedAbility;
    }

    public long getLastCastNanos() {
        return lastCastNanos;
    }

    public void setLastCastNanos(long lastCastNanos) {
        this.lastCastNanos = lastCastNanos;
    }

    /** Verrou anti double-clic / double-action (switch, évolution). */
    public boolean isBusy() {
        return busy;
    }

    public void setBusy(boolean busy) {
        this.busy = busy;
    }

    public boolean isDirty() {
        return dirty;
    }

    public void markDirty() {
        dirty = true;
    }

    public void clearDirty() {
        dirty = false;
    }
}
