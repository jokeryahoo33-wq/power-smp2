package fr.powersmp;

import fr.powersmp.boss.BossManager;
import fr.powersmp.command.AdminCommand;
import fr.powersmp.command.PowerCommand;
import fr.powersmp.cooldown.CooldownManager;
import fr.powersmp.data.Database;
import fr.powersmp.data.PlayerDataManager;
import fr.powersmp.economy.EconomyBridge;
import fr.powersmp.evolution.EvolutionManager;
import fr.powersmp.gui.GuiManager;
import fr.powersmp.item.CustomItems;
import fr.powersmp.listener.AbilityListener;
import fr.powersmp.listener.GuiListener;
import fr.powersmp.listener.PlayerListener;
import fr.powersmp.listener.ProgressListener;
import fr.powersmp.power.Grade;
import fr.powersmp.power.PowerManager;
import fr.powersmp.trial.TrialManager;
import fr.powersmp.util.Messages;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;
import java.util.logging.Level;

/** Power SMP : pouvoirs, grades et évolution par activités en jeu. */
public final class PowerSMP extends JavaPlugin {

    private Messages messages;
    private Database database;
    private PlayerDataManager dataManager;
    private CooldownManager cooldowns;
    private EconomyBridge economy;
    private CustomItems items;
    private PowerManager powers;
    private EvolutionManager evolution;
    private BossManager bosses;
    private TrialManager trials;
    private GuiManager gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        messages.load();

        database = new Database(this);
        try {
            database.init();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Impossible d'ouvrir la base SQLite : le plugin est désactivé.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        dataManager = new PlayerDataManager(this, database);
        cooldowns = new CooldownManager();
        economy = new EconomyBridge(this);
        items = new CustomItems(this);
        powers = new PowerManager(this);
        evolution = new EvolutionManager(this);
        bosses = new BossManager(this);
        trials = new TrialManager(this);
        gui = new GuiManager(this);

        Objects.requireNonNull(getCommand("power")).setExecutor(new PowerCommand(this));
        Objects.requireNonNull(getCommand("powersmp")).setExecutor(new AdminCommand(this));

        Bukkit.getPluginManager().registerEvents(new PlayerListener(this), this);
        Bukkit.getPluginManager().registerEvents(new AbilityListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ProgressListener(this), this);

        dataManager.startAutosave();
        // /reload ou redémarrage à chaud : on recharge les joueurs déjà connectés.
        for (Player p : Bukkit.getOnlinePlayers()) {
            dataManager.load(p);
        }
        // Vault/EssentialsX enregistrent l'économie un peu après nous : on vérifie quelques secondes plus tard.
        getServer().getScheduler().runTaskLater(this, () -> {
            if (!economy.isReady()) {
                getLogger().warning("Aucune économie Vault détectée : /power switch sera refusé tant que Vault + EssentialsX ne sont pas installés.");
            }
        }, 200L);
        getLogger().info("PowerSMP activé.");
    }

    @Override
    public void onDisable() {
        if (dataManager == null) {
            return;
        }
        trials.shutdown();
        bosses.shutdown();
        dataManager.shutdown();
    }

    /** /powersmp reload : relit config.yml et messages.yml (les valeurs des capacités sont lues à chaque usage). */
    public void reloadPlugin() {
        reloadConfig();
        messages.load();
    }

    /** Texte coloré d'un grade (voir "grades:" dans config.yml). */
    public String gradeLabel(Grade grade) {
        return getConfig().getString("grades." + grade.name(), "&f" + grade.name());
    }

    public Messages getMessages() {
        return messages;
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    public CooldownManager getCooldowns() {
        return cooldowns;
    }

    public EconomyBridge getEconomy() {
        return economy;
    }

    public CustomItems getItems() {
        return items;
    }

    public PowerManager getPowers() {
        return powers;
    }

    public EvolutionManager getEvolution() {
        return evolution;
    }

    public BossManager getBosses() {
        return bosses;
    }

    public TrialManager getTrials() {
        return trials;
    }

    public GuiManager getGui() {
        return gui;
    }
}
