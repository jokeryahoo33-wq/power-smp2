# PowerSMP — V1 (Lightning)

Plugin Paper 1.21.11 pour le serveur **Power SMP** : un pouvoir par joueur, grades F → SSS, évolution par activités
(objets rares, boss, épreuves, kills, matériaux), switch payant à prix fixe (10 000 000 $) via l'économie existante (Vault).

## Arborescence

```
PowerSMP/
├─ pom.xml
├─ .github/workflows/build.yml          (compilation automatique sur GitHub)
└─ src/main/
   ├─ resources/
   │  ├─ plugin.yml                      commandes + permissions
   │  ├─ config.yml                      pouvoirs, capacités, grades, conditions, boss, épreuves, objets, GUI
   │  └─ messages.yml                    tous les textes
   └─ java/fr/powersmp/
      ├─ PowerSMP.java                   classe principale
      ├─ data/        PlayerData, PlayerDataManager, Database (SQLite)
      ├─ power/       Grade, Power, Ability, PowerManager
      │  └─ lightning/ LightningPower + 5 briques de capacités
      ├─ cooldown/    CooldownManager
      ├─ evolution/   EvolutionManager (conditions de grade)
      ├─ item/        CustomItems (Éclat de Foudre, Noyau...)
      ├─ boss/        BossManager
      ├─ trial/       TrialManager (épreuves / sanctuaires)
      ├─ economy/     EconomyBridge (Vault)
      ├─ gui/         GuiManager (choix, confirmation, switch)
      ├─ command/     PowerCommand (/power), AdminCommand (/powersmp)
      ├─ listener/    Player, Ability, Gui, Progress
      └─ util/        Text, Messages, Combat
```

## Compiler

**Option A — sur ton PC** : installer Java 21 (JDK) et Maven, puis dans le dossier du projet :

```
mvn clean package
```

Le fichier est créé dans `target/PowerSMP-1.0.0.jar`.

**Option B — sans rien installer** : crée un dépôt GitHub, envoie-y tout le dossier, onglet **Actions** →
« Build PowerSMP » → télécharge l'artefact `PowerSMP-jar`.

## Installer sur Aternos

1. Sur Aternos, le logiciel du serveur doit être **Paper** (onglet *Logiciel*), version **1.21.11**.
2. Installe les plugins **Vault** et **EssentialsX** (onglet *Plugins*, ou en les envoyant dans le dossier `plugins`).
   Vault est indispensable pour utiliser ton économie existante (le switch est refusé sans lui).
3. Onglet **Fichiers** → dossier `plugins` → envoie `PowerSMP-1.0.0.jar`.
4. Redémarre le serveur. Les fichiers `config.yml` et `messages.yml` apparaissent dans `plugins/PowerSMP/`.

## Permissions (LuckPerms)

| Permission | Rôle | Défaut |
|---|---|---|
| `powersmp.use` | /power et lancer ses capacités | tous |
| `powersmp.choose` | choisir son premier pouvoir | tous |
| `powersmp.switch` | changer de pouvoir (payant) | tous |
| `powersmp.reload` | `/powersmp reload` | op |
| `powersmp.admin` | toutes les commandes admin | op |

## Contrôles en jeu

- **Shift + F** : lance la capacité sélectionnée
- **Shift + molette** : change de capacité (ou `/power select <capacité>`)

## Commandes de test (dans cet ordre)

```
/power                          -> menu de choix (ou /power choose), choisis Lightning, confirme
/power abilities
/power info
/powersmp setgrade <toi> C      -> tester les capacités débloquées (Shift+F)
/powersmp item give <toi> lightning_shard 3
/powersmp item give <toi> lightning_core 1
/powersmp boss spawn storm_guardian      -> tue-le : progression + Noyau de Foudre
/powersmp sanctuary set lightning_sanctuary   -> là où tu te tiens
/power trial lightning_sanctuary         -> survis 60 s dans la zone
/power                          -> conditions
/power evolve                   -> passe au grade suivant
/power switch                   -> menu payant, confirmation, 10 000 000 $
/powersmp info <joueur>
/powersmp reset <joueur>
/powersmp reload
```

Avant de tester `/power switch`, donne-toi de l'argent avec EssentialsX (`/eco give <toi> 10000000`).

## Ajouter un pouvoir (Fire, Ice...)

1. Dans `config.yml`, passe `powers.fire.enabled` à `true` et ajoute ses `abilities` et son `evolution` (copie la structure de `lightning`).
2. Crée `power/fire/FirePower.java` (comme `LightningPower`) et ses capacités (étends `Ability`, ou réutilise les briques de `Combat`).
3. Ajoute `register(new FirePower(plugin));` dans le constructeur de `PowerManager`.

Rien d'autre à toucher : GUI, sauvegarde, cooldowns, switch et évolution fonctionnent déjà pour tous les pouvoirs.

## Remarques

- Les éclairs sont **visuels** (`strikeLightningEffect`) et les dégâts sont appliqués par le plugin : pas d'incendie, pas de dégâts aux blocs,
  rien à signaler à CoreProtect.
- Les vrais emojis (🔥 🌊...) s'affichent comme des carrés dans la police de Minecraft ; la config utilise des symboles compatibles (⚡ ♨ ❄ ☁ ☾ ◆ ≈ ✿ ☀ ✦), modifiables.
- Les valeurs de conditions, de butin et de dégâts sont des **réglages de départ** à équilibrer selon ton serveur.
